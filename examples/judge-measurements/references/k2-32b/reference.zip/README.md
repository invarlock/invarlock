# K2 frozen-answer judge reference

This bundle freezes outcome-blind pilot and final subsets of an existing paired
K2 Horizon 32B campaign. It contains no new judge results or fabricated ratings.
Run the matching source checkout's helper with an installed InvarLock package:

```bash
python examples/judge_measurements_reference.py validate --bundle reference
```

Optional `--campaign-root` rechecks every source file and reconstructs extraction
from the original blocks and endpoints. Default validation is self-contained and
checks retained mappings, selection, source metadata, contract construction and
blinded review exports. It cannot authenticate omitted original block membership
from hashes alone. An independently obtained `--expected-sha256` manifest pin
protects the bundle boundary; a bundle cannot authorize itself.

Selection ranks compact sorted UTF-8 JSON [seed, workflow, split, case_id] using
SHA-256 with seed invarlock-k2-32b-judge-reference-v1. The pilot takes 20 cases per
stratum in rank order, skipping reused clusters. Final then takes one ranked case
from every remaining eligible cluster, without using answers or scores. No source
cluster appears twice across pilot and final within a workflow. QA is English
only; both sides must be complete. All excluded and eligible population counts
are reported from the retained inventory; full original inputs can be cross-checked
only when the optional campaign root is available.

Rubric-development review includes every pilot case (40 per workflow). Complete
this review before declaring a final rubric and plan immutable. Current final
plans are candidates pending that review: confirm the rubric unchanged or regenerate
plans before any final model call. Regeneration must preserve frozen final membership.
Final candidate_plan.json wraps the candidate plan and policy and is deliberately
not an executable judge-measurement-plan document. Only pilot/plan.json is ready
for the collection API at this stage.

The untouched final-validation review takes 40 cases per stratum from final with
its own hash ranking. Give reviewers only the appropriate
human_review/rubric_development/<workflow>.json or
human_review/final_validation/<workflow>.json. That file contains
anonymous review IDs, unchanged input and two responses with independently hashed
position order; it exposes no native scores, source IDs or A/B role labels. Review
order is also independently ranked. Blinding is procedural: the full bundle and
public deterministic algorithm allow the study operator to recover the mapping.
Freeze human judgments before giving reviewers the full source bundle.

Judge plans and analysis policies, when supplied, are separately frozen per
workflow and split. They bind exact answers and rendered requests; repetitions
do not increase independent-unit counts. The final benchmark remains curated,
with no claim of traffic generalization. See attribution/ATTRIBUTION.md before
redistributing source-derived content.
