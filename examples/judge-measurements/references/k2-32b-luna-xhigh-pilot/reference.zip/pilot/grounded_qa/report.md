# InvarLock bounded judge report

**Recorded policy result: More evidence needed**

Comparison of repeated judgments of frozen baseline and subject answers on the declared benchmark. This metric is advisory and does not gate required decisions.

## What was compared

- **Baseline:** Recorded run: k2-32b-grounded_qa-pilot-baseline
- **Subject:** Recorded run: k2-32b-grounded_qa-pilot-subject
- **Evaluation mode:** Captured evaluator outputs
- **Baseline evaluator:** K2 frozen answer reference 1
- **Baseline model revision:** Unavailable in recorded context
- **Baseline capture role:** Unavailable in recorded context
- **Baseline workflow:** grounded_qa
- **Baseline dataset:** squad2
- **Baseline records:** 40
- **Baseline effective message roles:** Unavailable in recorded context
- **Subject evaluator:** K2 frozen answer reference 1
- **Subject model revision:** Unavailable in recorded context
- **Subject capture role:** Unavailable in recorded context
- **Subject workflow:** grounded_qa
- **Subject dataset:** squad2
- **Subject records:** 40
- **Subject effective message roles:** Unavailable in recorded context
- **Captured comparison:** Model-key comparison is unavailable because recorded values are missing or mixed.
- **Captured comparison:** Prompt comparison unavailable: complete, uniquely paired effective messages were not recorded.
- **Judge provider:** openai
- **Requested judge:** openai/gpt-5.6-luna
- **Resolved judges:** gpt-5.6-luna
- **Reasoning effort:** xhigh
- **Rubric:** Rate whether the candidate answer satisfies the grounded question-answering task using only the supplied context. correct: it directly and fully answers the question with supported information, uses NO_ANSWER exactly when the context does not answer the question, and contains no material contradiction or unsupported claim. partially_correct: it contains relevant supported information but is incomplete, imprecise, or has a minor content or format defect that does not reverse the answer. incorrect: it is unsupported or materially wrong, fails to answer, makes the wrong answerability decision, contradicts the context, or violates the required format so the result cannot be used.
- **Judge prompt:** Grade the candidate answer against the task in the input and the declared rubric. Return exactly one JSON object with a rating field and one allowed rating label.
- **Prompt demonstrations:** 0
- **Prompt references:** 0
- **Scale:** incorrect = 0, partially_correct = 0.5, correct = 1
- **Coverage:** 40 cases; 40 independent units; 240/240 completed trials

## What was checked

- **Captured answer provenance:** Evaluator, artifact, configuration and model labels are source assertions retained with the captured runs; runtime execution has not been independently established.
- **Authentication:** Signature present; recipient signer authorization has not been performed.
- **Measurement and analysis replay:** Completed offline against the retained plan and source records.
- **Policy result:** insufficient_evidence
- **Recipient acceptance:** Not performed by report.

## grounded_qa-judge-quality — Advisory metric; fixed benchmark; equal independent-unit weights

**More evidence needed**. The declared advisory bounds are not established by the available evidence. maximum_interval_width_exceeded

| Baseline | Candidate | Change | Observed pairs |
| --- | --- | --- | --- |
| 0.820833333333333 | 0.779166666666667 | -0.041666666666667 | 40 cases; 40 independent units; 240/240 completed trials |

Paired independent-unit effect interval: [-0.5454, 0.4621] normalized rating.

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| paired_effect | insufficient_evidence | pass &#40;advisory only&#41; | Unavailable |

- Decision role: advisory; this metric does not gate required decisions.
- Allowed degradation: 1 &#40;higher is better&#41;.
- Minimum units: 40; maximum interval width: 1.
- Baseline and subject means describe the same complete schedule with equal independent-unit weights.
- Repetitions do not increase the number of independent units.

## Next steps

1. Use verify with an independently maintained judge recipient policy before relying on this result.

## Scope and limitations

- Equal-unit average expected judge score on the fixed scheduled benchmark; the paired effect is subject minus baseline. No population generalization is asserted.
- Details show the first 40 cases by case ID and at most 2000 characters per text excerpt; use report --case-id to select any retained case.
- A retained judgment does not establish model execution or immunity to prompt injection.

## Evidence identities

- **Baseline run:** k2-32b-grounded_qa-pilot-baseline
- **Baseline run digest:** sha256:3733e8203f16a277188874343ba47282ba7b9ec719918efd1cc5f7aec684cc61
- **Baseline attributed artifact:** sha256:b3fc4850a121aea4b00edcb90271ace64ee6b441396cd99f2e6b222d2503ed74
- **Baseline evaluator:** K2 frozen answer reference 1
- **Subject run:** k2-32b-grounded_qa-pilot-subject
- **Subject run digest:** sha256:b1abc8c9e43389b33367dfb2912ee17b98257d791591e647da63b9e9135266a4
- **Subject attributed artifact:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Subject evaluator:** K2 frozen answer reference 1
- **Baseline source digest:** sha256:8a59be5ec519aaec3a9295820cd59cc757e40ceecaf9747e91bf56c484a83dd1
- **Subject source digest:** sha256:c8090de05422f22a2dfe59f591078bcbd89b556282e8e2418c583a5187f369bb
- **Baseline artifact:** sha256:b3fc4850a121aea4b00edcb90271ace64ee6b441396cd99f2e6b222d2503ed74
- **Subject artifact:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Plan:** 9f3c27f748e1eab89f12a72eb017abb24a21e480a01f0e7ef3a2a0777062ba58
- **Intended subject:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Signer:** gpt-5.6-luna-xhigh-pilot-grounded_qa-signer
- **Signer key:** sha256:f0fbb16774238fd0ad7289d04dd9b5aae282375d5e626c3c69c49684c6cda667
