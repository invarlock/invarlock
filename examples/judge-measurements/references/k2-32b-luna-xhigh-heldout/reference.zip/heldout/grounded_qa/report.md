# InvarLock bounded judge report

**Recorded policy result: Policy satisfied**

Comparison of repeated judgments of frozen baseline and subject answers on the declared benchmark.

## What was compared

- **Baseline:** Recorded run: k2-32b-grounded_qa-final-baseline
- **Subject:** Recorded run: k2-32b-grounded_qa-final-subject
- **Evaluation mode:** Captured evaluator outputs
- **Baseline evaluator:** K2 frozen answer reference 1
- **Baseline model revision:** Unavailable in recorded context
- **Baseline capture role:** Unavailable in recorded context
- **Baseline workflow:** grounded_qa
- **Baseline dataset:** squad2
- **Baseline records:** 422
- **Baseline effective message roles:** Unavailable in recorded context
- **Subject evaluator:** K2 frozen answer reference 1
- **Subject model revision:** Unavailable in recorded context
- **Subject capture role:** Unavailable in recorded context
- **Subject workflow:** grounded_qa
- **Subject dataset:** squad2
- **Subject records:** 422
- **Subject effective message roles:** Unavailable in recorded context
- **Captured comparison:** Model-key comparison is unavailable because recorded values are missing or mixed.
- **Captured comparison:** Prompt comparison unavailable: complete, uniquely paired effective messages were not recorded.
- **Judge provider:** openai
- **Requested judge:** openai/gpt-5.6-luna
- **Resolved judges:** gpt-5.6-luna
- **Reasoning effort:** xhigh
- **Rubric:** Rate whether the candidate answer satisfies the grounded question-answering task using only the supplied context. correct: it directly and fully answers the question with supported information, uses NO_ANSWER exactly when the context does not answer the question, and contains no material contradiction or unsupported claim. partially_correct: it contains relevant supported information but is incomplete, imprecise, or has a minor content or format defect that does not reverse the answer. incorrect: it is unsupported or materially wrong, fails to answer, makes the wrong answerability decision, contradicts the context, or violates the required format so the result cannot be used.
- **Judge prompt:** Grade the candidate answer against the task in the input and the declared rubric. Return exactly one JSON object with a rating field and one allowed rating label.
- **Prompt demonstrations:** 0
- **Prompt references:** 0
- **Scale:** incorrect = 0, partially_correct = 0.5, correct = 1
- **Coverage:** 422 cases; 422 independent units; 2532/2532 completed trials

## What was checked

- **Captured answer provenance:** Evaluator, artifact, configuration and model labels are source assertions retained with the captured runs; runtime execution has not been independently established.
- **Authentication:** Signature present; recipient signer authorization has not been performed.
- **Measurement and analysis replay:** Completed offline against the retained plan and source records.
- **Policy result:** pass
- **Recipient acceptance:** Not performed by report.

## grounded_qa-judge-quality — Fixed benchmark; equal independent-unit weights

**Policy satisfied**. All declared required bounds are satisfied.

| Baseline | Candidate | Change | Observed pairs |
| --- | --- | --- | --- |
| 0.795813586097946 | 0.822669826224329 | 0.026856240126382 | 422 cases; 422 independent units; 2532/2532 completed trials |

Paired independent-unit effect interval: [-0.1282, 0.1819] normalized rating.

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| paired_effect | pass | pass | Passed |
| subject_bound | pass | pass | Passed |

- Decision role: required.
- Allowed degradation: 0.15 &#40;higher is better&#41;.
- Minimum units: 422; maximum interval width: 0.32.
- Baseline and subject means describe the same complete schedule with equal independent-unit weights.
- Repetitions do not increase the number of independent units.

## Next steps

1. Use verify with an independently maintained judge recipient policy before relying on this result.

## Scope and limitations

- Equal-unit average expected judge score on the fixed scheduled benchmark; the paired effect is subject minus baseline. No population generalization is asserted.
- Details show the first 50 cases by case ID and at most 2000 characters per text excerpt; use report --case-id to select any retained case.
- A retained judgment does not establish model execution or immunity to prompt injection.

## Evidence identities

- **Baseline run:** k2-32b-grounded_qa-final-baseline
- **Baseline run digest:** sha256:e153e09669f47730a3ed42ad8e015718a880471dbf8f824ca641dc438b60e10d
- **Baseline attributed artifact:** sha256:b3fc4850a121aea4b00edcb90271ace64ee6b441396cd99f2e6b222d2503ed74
- **Baseline evaluator:** K2 frozen answer reference 1
- **Subject run:** k2-32b-grounded_qa-final-subject
- **Subject run digest:** sha256:fa5d380cafc0076e591876879154710be470b16bab968dd9994128de9cb4c70c
- **Subject attributed artifact:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Subject evaluator:** K2 frozen answer reference 1
- **Baseline source digest:** sha256:8a59be5ec519aaec3a9295820cd59cc757e40ceecaf9747e91bf56c484a83dd1
- **Subject source digest:** sha256:c8090de05422f22a2dfe59f591078bcbd89b556282e8e2418c583a5187f369bb
- **Baseline artifact:** sha256:b3fc4850a121aea4b00edcb90271ace64ee6b441396cd99f2e6b222d2503ed74
- **Subject artifact:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Plan:** f446b746e4e65fc567b29041d37a8ad681ceda5482274de907a8fce8728132fd
- **Intended subject:** sha256:3e8221decc79aa13761623b0e4249f59ed5500d89517407db661578e2954afba
- **Signer:** gpt-5.6-luna-xhigh-heldout-grounded_qa-signer
- **Signer key:** sha256:98c401529e13900fbe119195411c4b6ff4b3a5648bd466e9ad9b67cd6e7ac704
