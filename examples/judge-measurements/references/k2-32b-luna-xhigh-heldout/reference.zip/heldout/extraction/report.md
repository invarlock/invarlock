# InvarLock bounded judge report

**Recorded policy result: Policy satisfied**

Comparison of repeated judgments of frozen baseline and subject answers on the declared benchmark.

## What was compared

- **Baseline:** Recorded run: k2-32b-extraction-final-baseline
- **Subject:** Recorded run: k2-32b-extraction-final-subject
- **Evaluation mode:** Captured evaluator outputs
- **Baseline evaluator:** K2 frozen answer reference 1
- **Baseline model revision:** Unavailable in recorded context
- **Baseline capture role:** Unavailable in recorded context
- **Baseline workflow:** extraction
- **Baseline dataset:** sgd
- **Baseline records:** 1,288
- **Baseline effective message roles:** Unavailable in recorded context
- **Subject evaluator:** K2 frozen answer reference 1
- **Subject model revision:** Unavailable in recorded context
- **Subject capture role:** Unavailable in recorded context
- **Subject workflow:** extraction
- **Subject dataset:** sgd
- **Subject records:** 1,288
- **Subject effective message roles:** Unavailable in recorded context
- **Captured comparison:** Model-key comparison is unavailable because recorded values are missing or mixed.
- **Captured comparison:** Prompt comparison unavailable: complete, uniquely paired effective messages were not recorded.
- **Judge provider:** openai
- **Requested judge:** openai/gpt-5.6-luna
- **Resolved judges:** gpt-5.6-luna
- **Reasoning effort:** xhigh
- **Rubric:** Rate whether the candidate answer satisfies the extraction task in the input. correct: it is a raw JSON array containing every and only directly mentioned allowed noncategorical slot/value pair, with exact slot names, verbatim nonempty values, no duplicates, and &#91;&#93; when none occur. partially_correct: it captures some required pairs but has a limited omission, extra pair, value, duplication, or format defect while remaining substantially useful. incorrect: it is materially wrong, inferred or copied from excluded context, omits or adds substantial content, is not interpretable as the required result, or gives a nonempty result when none occur.
- **Judge prompt:** Grade the candidate answer against the task in the input and the declared rubric. Return exactly one JSON object with a rating field and one allowed rating label.
- **Prompt demonstrations:** 0
- **Prompt references:** 0
- **Scale:** incorrect = 0, partially_correct = 0.5, correct = 1
- **Coverage:** 1288 cases; 1288 independent units; 7728/7728 completed trials

## What was checked

- **Captured answer provenance:** Evaluator, artifact, configuration and model labels are source assertions retained with the captured runs; runtime execution has not been independently established.
- **Authentication:** Signature present; recipient signer authorization has not been performed.
- **Measurement and analysis replay:** Completed offline against the retained plan and source records.
- **Policy result:** pass
- **Recipient acceptance:** Not performed by report.

## extraction-judge-quality — Fixed benchmark; equal independent-unit weights

**Policy satisfied**. All declared required bounds are satisfied.

| Baseline | Candidate | Change | Observed pairs |
| --- | --- | --- | --- |
| 0.894539337474120 | 0.903856107660455 | 0.009316770186335 | 1288 cases; 1288 independent units; 7728/7728 completed trials |

Paired independent-unit effect interval: [-0.07946, 0.09809] normalized rating.

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| paired_effect | pass | pass | Passed |
| subject_bound | pass | pass | Passed |

- Decision role: required.
- Allowed degradation: 0.1 &#40;higher is better&#41;.
- Minimum units: 1288; maximum interval width: 0.18.
- Baseline and subject means describe the same complete schedule with equal independent-unit weights.
- Repetitions do not increase the number of independent units.

## Next steps

1. Use verify with an independently maintained judge recipient policy before relying on this result.

## Scope and limitations

- Equal-unit average expected judge score on the fixed scheduled benchmark; the paired effect is subject minus baseline. No population generalization is asserted.
- Details show the first 50 cases by case ID and at most 2000 characters per text excerpt; use report --case-id to select any retained case.
- A retained judgment does not establish model execution or immunity to prompt injection.

## Evidence identities

- **Baseline run:** k2-32b-extraction-final-baseline
- **Baseline run digest:** sha256:3bd6964aab104d6acbccab3608310bf3dcc7f49dbeebeb93a85f0e418cea311f
- **Baseline attributed artifact:** sha256:8bd11ef22999a01345b73399f75df0189ae4b8cf5c19ae69c3a363039c2bd4bf
- **Baseline evaluator:** K2 frozen answer reference 1
- **Subject run:** k2-32b-extraction-final-subject
- **Subject run digest:** sha256:7ba8068c9334ae132d6f373a229fea1b4600e4bce59e380ef17caea4e7b67196
- **Subject attributed artifact:** sha256:a7abb81bd894dec1d114f484d140a05d38a0e539df1b87700e96d447c1055a44
- **Subject evaluator:** K2 frozen answer reference 1
- **Baseline source digest:** sha256:a5e7747b746671a773f155f07cf9e84994090c97fe3735821549639a7edcdff4
- **Subject source digest:** sha256:fffe741cd630f2acec1b3603f6bd8ca049f31874711679fae8aebbf52cedc33d
- **Baseline artifact:** sha256:8bd11ef22999a01345b73399f75df0189ae4b8cf5c19ae69c3a363039c2bd4bf
- **Subject artifact:** sha256:a7abb81bd894dec1d114f484d140a05d38a0e539df1b87700e96d447c1055a44
- **Plan:** 9375d6a3bfba9089713a49831d7be52445f2efd4c62cfeec0009242df500b8a8
- **Intended subject:** sha256:a7abb81bd894dec1d114f484d140a05d38a0e539df1b87700e96d447c1055a44
- **Signer:** gpt-5.6-luna-xhigh-heldout-extraction-signer
- **Signer key:** sha256:594439d462e72e3eecf733bbe8e99c50943274b0663fdfbc98129ff343e2468f
