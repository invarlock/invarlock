# InvarLock captured comparison

**Recorded policy result: Policy not met**

The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits. Across 8 usable pairs, the subject's Reference accuracy was 12.5%, compared with 0% for the baseline, a change of +12.5 pp. The 95% interval for the change runs from -21.52 to 47.09 pp. The policy requires the interval to stay at or above -2 pp. No absolute minimum score is required by this policy.

## What was compared


### Observed model: Differs

- **Baseline:** mistralai/Mistral-7B-v0.1
- **Subject:** mistralai/Mistral-7B-Instruct-v0.1

### Deployment: Differs

- **Baseline:** mistral-baseline
- **Subject:** mistral-subject

### Requested model: Differs

- **Baseline:** mistralai/Mistral-7B-v0.1
- **Subject:** mistralai/Mistral-7B-Instruct-v0.1

### Exposed revision: Differs

- **Baseline:** 27d67f1b5f57dc0953326b2601d68371d40ea8da
- **Subject:** ec5deb64f2c6e6fa90c1abf74a91d5c93a9669ca

### Observation window: Differs

- **Baseline:** 2026-09-20T19:50:25.375704Z → 2026-09-20T19:50:29.815115Z
- **Subject:** 2026-09-20T19:50:22.608692Z → 2026-09-20T19:50:25.540580Z

### Matching displayed fields

Matching previews do not establish equality of the complete retained fields.

- **Provider:** local
- **Service:** reference-task-service
- **Service provenance:** Captured service declaration. Model weights are not identified.
- **Service harness:** live-loopback-http 1
- **Evaluator:** promptfoo 0.121.19
- **Dataset:** Mixed or incomplete across records
- **Records:** 8

### Additional fields

- **Evaluation mode:** Captured evaluator outputs
- **Measurement scope:** Verification checks retained observations; it does not remeasure the service.

### Recorded changes

- Declared service fields differ: deployment, requested model, observed model, exposed revision. This comparison does not identify the cause of an observed performance change or establish identical hidden weights.
- Prompt comparison unavailable in this report projection: no complete, uniquely paired supported message view is available.

## What was checked

- **Pack format:** invarlock/evidence-pack-v2
- **Input checks:** Evidence structure and comparison bindings checked.
- **Signing:** Signed manifest verified. This rendering has not authenticated it against a recipient-owned key.
- **Replay and scoring:** Scoring and replay were not performed by report.
- **Independent recipient verification:** Not performed by report. Use invarlock verify with independently supplied inputs.

## Reference accuracy: overall

**Policy not met**. The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits.

| Baseline | Subject | Change | Usable pairs |
| --- | --- | --- | --- |
| 0% | 12.5% | +12.5 pp | 8 |

Baseline: 0 of 8 matched.

Subject: 1 of 8 matched.

Usable pairs: 0 missing · 8 included · ≥ 8 required.

Paired 95% confidence interval &#40;Newcombe hybrid score&#41;: [-21.52, 47.09] pp.

### How to read this comparison

**Change:** The marker shows the observed change between subject and baseline. A change in percentage points &#40;pp&#41; is the subject percentage minus the baseline percentage.

**Interval:** The bar shows uncertainty around that change. Its left endpoint is the lower bound; its right endpoint is the upper bound. The interval level does not tell you how often model runs would pass or fail the policy.

**Policy rule:** The paired lower bound &#40;left endpoint&#41; must be at least the policy minimum. The whole interval must lie on the allowed side of the threshold for this bound check to pass.

**No change:** The dashed line marks no change. An interval crossing it includes changes in either direction. A worse observed score describes this run; policy rejection alone does not prove worse performance beyond these cases.

### How this interval was calculated

Baseline and subject are paired on the same 8 cases in this scope. Newcombe hybrid score uses their paired match outcomes to form a nominal 95% confidence interval for the accuracy change.

Change is subject accuracy minus baseline accuracy in percentage points, not relative percent change. The confidence level describes the interval method, not the share of correct answers.

Each metric and scope has its own interval; these intervals do not provide a simultaneous confidence guarantee across all results or establish a representative production sample.

### Decision checks

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| Complete paired results | 8 of 8 | All included pairs | Passed |
| Included pair count | 8 | &gt;= 8 | Passed |
| Allowed change | -21.52 pp | &gt;= -2 pp | Not met |
| Interval width | 68.61 pp | &lt;= 10 pp | Not met |

- Higher values are better.
- Recorded scoring basis: expected and output values, scored when the comparison was created.
- 8 usable pairs; 0 missing results; 8 included pairs. Counts in overlapping slices must not be added together.
- Matches: baseline 0 of 8; subject 1 of 8.
- No absolute minimum score is required by this policy.

## Next steps

1. Review the recorded checks against the approved requirements.
2. For a signed handoff, run invarlock verify with independent signer, policy, request and complete-run anchors and an external signed receipt.
3. Use the comparison JSON and JUnit outputs in CI; preserve missing results and the original policy.

## Scope and limitations

- Recorded scores retain source judgments; only their aggregation is recomputed.
- Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.
- Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.
- A policy pass does not establish truthful model execution, general quality, safety or compliance.
- Hosted identity digests authenticate declared service descriptors and observation windows; they do not identify underlying weights or establish hidden configuration or later service behavior.
- Model and prompt context is evaluator-recorded provenance, not independent execution or model-identity attestation.

## Evidence identities

- **Manifest:** sha256:3428484103b772b3697509e487b4d9145e68fa7fc4d7bed5950d2f0cdc934487
- **Comparison:** sha256:00c41a9708a52ded8a92596217b4ac7543f1d6264f99f870e3855e3a7d5d8e80
- **Evidence signer:** sha256:5877a24c4787082de235bc264ca5345dfe7b355218bceb3ae86c852cb475dc5c
- **Baseline run:** live-promptfoo-baseline
- **Baseline run digest:** sha256:08d5d47cc6f47343050bb9c56dcd960e1d90d3f08e1bb3716d1f2602b7c3a52f
- **Baseline service identity:** sha256:f787425530383ba41196847a65f6c9892817110d8b31406902435af13ccec572
- **Baseline evaluator:** promptfoo 0.121.19
- **Baseline service configuration:** sha256:2d75fd6e15ad9ab37c6c25aa1293a29cd6e7c31849ae3e5ecc4dcd1f49c37c17
- **Baseline harness source:** sha256:3356817238c0d6a7632d3369fe744efeb4fd40a2cba4586187d69cab4ec81dda
- **Subject run:** live-promptfoo-subject
- **Subject run digest:** sha256:be0c95a2e840630699cd008ab03188fb2ee0105da2d8da344385233c158827ed
- **Subject service identity:** sha256:f994514583e9bda2cea66fb4be896630bf3fe3db046cf89ceb019ab80948fee3
- **Subject evaluator:** promptfoo 0.121.19
- **Subject service configuration:** sha256:2d75fd6e15ad9ab37c6c25aa1293a29cd6e7c31849ae3e5ecc4dcd1f49c37c17
- **Subject harness source:** sha256:3356817238c0d6a7632d3369fe744efeb4fd40a2cba4586187d69cab4ec81dda
- **Baseline binding:** sha256:08d5d47cc6f47343050bb9c56dcd960e1d90d3f08e1bb3716d1f2602b7c3a52f
- **Policy binding:** sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e
- **Subject binding:** sha256:be0c95a2e840630699cd008ab03188fb2ee0105da2d8da344385233c158827ed

## Recorded metric and scope identifiers

```json
[
  {
    "display_metric": "Reference accuracy",
    "display_scope": "overall",
    "metric": "reference_accuracy",
    "result": 1,
    "scope": "overall"
  }
]
```

## Baseline declared service configuration

```json
{
  "limits": {
    "depth": 6,
    "nodes": 128,
    "string_characters": 256
  },
  "note": "Full declared configuration remains in the captured run. Its digest identifies the declaration.",
  "preview_only": true,
  "text": "{\n  \"add_bos_token\": false,\n  \"async_weight_loading\": false,\n  \"attn_implementation\": \"eager\",\n  \"backend\": \"causal\",\n  \"batch_size\": 1,\n  \"chat_template\": false,\n  \"deterministic_algorithms\": true,\n  \"device\": \"cuda\",\n  \"dtype\": \"float16\",\n  \"local_files_only\": true,\n  \"logits_cache\": false,\n  \"max_length\": 1024,\n  \"max_new_tokens\": 32,\n  \"maximum_model_file_bytes\": 21474836480,\n  \"mps_memory_fraction\": 0.42,\n  \"parallelize\": false,\n  \"result_cache\": false,\n  \"seed\": 0,\n  \"separate_model_instances\": true,\n  \"softmax_dtype\": \"float32\",\n  \"timeout_seconds\": 3600,\n  \"torch_threads\": 4,\n  \"truncation\": false,\n  \"trust_remote_code\": false,\n  \"use_fast_tokenizer\": true,\n  \"use_safetensors\": true\n}"
}
```

## Subject declared service configuration

```json
{
  "limits": {
    "depth": 6,
    "nodes": 128,
    "string_characters": 256
  },
  "note": "Full declared configuration remains in the captured run. Its digest identifies the declaration.",
  "preview_only": true,
  "text": "{\n  \"add_bos_token\": false,\n  \"async_weight_loading\": false,\n  \"attn_implementation\": \"eager\",\n  \"backend\": \"causal\",\n  \"batch_size\": 1,\n  \"chat_template\": false,\n  \"deterministic_algorithms\": true,\n  \"device\": \"cuda\",\n  \"dtype\": \"float16\",\n  \"local_files_only\": true,\n  \"logits_cache\": false,\n  \"max_length\": 1024,\n  \"max_new_tokens\": 32,\n  \"maximum_model_file_bytes\": 21474836480,\n  \"mps_memory_fraction\": 0.42,\n  \"parallelize\": false,\n  \"result_cache\": false,\n  \"seed\": 0,\n  \"separate_model_instances\": true,\n  \"softmax_dtype\": \"float32\",\n  \"timeout_seconds\": 3600,\n  \"torch_threads\": 4,\n  \"truncation\": false,\n  \"trust_remote_code\": false,\n  \"use_fast_tokenizer\": true,\n  \"use_safetensors\": true\n}"
}
```

## Bound policy &#40;configuration preview&#41;

```json
{
  "format": "invarlock/comparison-policy-v1",
  "metrics": [
    {
      "aggregation": "mean",
      "configuration": {
        "limits": {
          "depth": 6,
          "nodes": 128,
          "string_characters": 256
        },
        "note": "Display preview, not a replacement configuration. Full configuration remains in evidence under the original policy binding.",
        "preview_only": true,
        "text": "{}"
      },
      "direction": "higher",
      "kind": "exact_match",
      "maximum_interval_width": 0.1,
      "maximum_regression": 0.02,
      "minimum_count": 8,
      "name": "reference_accuracy",
      "unit": "score"
    }
  ],
  "slices": []
}
```

## Exact comparison data

```json
{
  "bindings": {
    "baseline": "sha256:08d5d47cc6f47343050bb9c56dcd960e1d90d3f08e1bb3716d1f2602b7c3a52f",
    "policy": "sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e",
    "subject": "sha256:be0c95a2e840630699cd008ab03188fb2ee0105da2d8da344385233c158827ed"
  },
  "decision": "regression",
  "format": "invarlock/multi-metric-comparison-v1",
  "limitations": [
    "Recorded scores retain source judgments; only their aggregation is recomputed.",
    "Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.",
    "Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.",
    "A policy pass does not establish truthful model execution, general quality, safety or compliance.",
    "Hosted identity digests authenticate declared service descriptors and observation windows; they do not identify underlying weights or establish hidden configuration or later service behavior."
  ],
  "metrics": [
    {
      "aggregation": "mean",
      "baseline_mean": 0.0,
      "count": 8,
      "decision": "regression",
      "delta": 0.125,
      "direction": "higher",
      "interval": {
        "lower": -0.2152402668913369,
        "mass": 0.95,
        "method": "newcombe_hybrid_score_paired_v2",
        "replicates": 0,
        "upper": 0.4708881822128535
      },
      "kind": "exact_match",
      "missing_count": 0,
      "missing_ids_preview": [],
      "missing_ids_preview_is_complete": true,
      "name": "reference_accuracy",
      "reasons": [
        "lower interval bound exceeds allowed regression"
      ],
      "scoring_assurance": "recomputed",
      "slice": "overall",
      "subject_mean": 0.125,
      "unit": "score"
    }
  ]
}
```
