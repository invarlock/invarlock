# InvarLock captured comparison

**Recorded policy result: Policy not met**

The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits. Across 64 usable pairs, the subject's Reference accuracy was 1.562%, compared with 0% for the baseline, a change of +1.562 pp. The 95% interval for the change runs from -4.244 to 8.334 pp. The policy requires the interval to stay at or above -2 pp. No absolute minimum score is required by this policy.

## What was compared


### Recorded run: Differs

- **Baseline:** live-inspect-ai-baseline
- **Subject:** live-inspect-ai-subject

### Matching displayed fields

Matching previews do not establish equality of the complete retained fields.

- **Evaluator:** inspect-ai 0.3.254
- **Model revision:** Unavailable in recorded context
- **Capture role:** Unavailable in recorded context
- **Workflow:** Unavailable in recorded context
- **Dataset:** Mixed or incomplete across records
- **Records:** 64
- **Effective message roles:** Unavailable in recorded context

### Additional fields

- **Evaluation mode:** Captured evaluator outputs

### Recorded changes

- Model-key comparison is unavailable because recorded values are missing or mixed.
- Prompt comparison unavailable in this report projection: no complete, uniquely paired supported message view is available.

## What was checked

- **Pack format:** invarlock/evidence-pack-v2
- **Input checks:** Evidence structure and comparison bindings checked.
- **Signing:** Signed manifest verified. This rendering has not authenticated it against a recipient-owned key.
- **Replay and scoring:** Scoring and replay were not performed by report.
- **Independent recipient verification:** Not performed by report. Use invarlock verify with independently supplied inputs.

## Reference accuracy: overall

**Policy not met**. The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits.

| Baseline | Subject | Change | Usable pairs |
| --- | --- | --- | --- |
| 0% | 1.562% | +1.562 pp | 64 |

Baseline: 0 of 64 matched.

Subject: 1 of 64 matched.

Usable pairs: 0 missing · 64 included · ≥ 64 required.

Paired 95% confidence interval &#40;Newcombe hybrid score&#41;: [-4.244, 8.334] pp.

### How to read this comparison

**Change:** The marker shows the observed change between subject and baseline. A change in percentage points &#40;pp&#41; is the subject percentage minus the baseline percentage.

**Interval:** The bar shows uncertainty around that change. Its left endpoint is the lower bound; its right endpoint is the upper bound. The interval level does not tell you how often model runs would pass or fail the policy.

**Policy rule:** The paired lower bound &#40;left endpoint&#41; must be at least the policy minimum. The whole interval must lie on the allowed side of the threshold for this bound check to pass.

**No change:** The dashed line marks no change. An interval crossing it includes changes in either direction. A worse observed score describes this run; policy rejection alone does not prove worse performance beyond these cases.

### How this interval was calculated

Baseline and subject are paired on the same 64 cases in this scope. Newcombe hybrid score uses their paired match outcomes to form a nominal 95% confidence interval for the accuracy change.

Change is subject accuracy minus baseline accuracy in percentage points, not relative percent change. The confidence level describes the interval method, not the share of correct answers.

Each metric and scope has its own interval; these intervals do not provide a simultaneous confidence guarantee across all results or establish a representative production sample.

### Decision checks

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| Complete paired results | 64 of 64 | All included pairs | Passed |
| Included pair count | 64 | &gt;= 64 | Passed |
| Allowed change | -4.244 pp | &gt;= -2 pp | Not met |
| Interval width | 12.58 pp | &lt;= 10 pp | Not met |

- Higher values are better.
- Recorded scoring basis: expected and output values, scored when the comparison was created.
- 64 usable pairs; 0 missing results; 64 included pairs. Counts in overlapping slices must not be added together.
- Matches: baseline 0 of 64; subject 1 of 64.
- No absolute minimum score is required by this policy.

## Next steps

1. Review the recorded checks against the approved requirements.
2. For a signed handoff, run invarlock verify with independent signer, policy, request and complete-run anchors and an external signed receipt.
3. Use the comparison JSON and JUnit outputs in CI; preserve missing results and the original policy.

## Scope and limitations

- Recorded scores retain source judgments; only their aggregation is recomputed.
- Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.
- Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.
- A policy pass does not establish truthful model execution, general quality, safety or compliance.
- Model and prompt context is evaluator-recorded provenance, not independent execution or model-identity attestation.

## Evidence identities

- **Manifest:** sha256:d7edfe47aced780fab4d60dba8a0885cb61049ae037eab43da83b4a20d823623
- **Comparison:** sha256:63a0d152dfcf4994e00484fdd303d29f3d70f9ef98a07763746e6619d9fc7982
- **Evidence signer:** sha256:c7d1a1060ed89888af83d0171e4a0ccf2bf93854c470120a5aa7e42e87e7bfd6
- **Baseline run:** live-inspect-ai-baseline
- **Baseline run digest:** sha256:75946ae28ef26de26a8b881c59c041ca0e8e97f60b8849c999ee8bd9c5c8be6e
- **Baseline attributed artifact:** sha256:c8e5d83cef2df1fa38f189fbbaab100571622addb05bb812fcc324cadbf099ec
- **Baseline evaluator:** inspect-ai 0.3.254
- **Subject run:** live-inspect-ai-subject
- **Subject run digest:** sha256:d389a09205b5b9ad053ed291e5a4c439404f0d310578cd6cdb9f431a6353721f
- **Subject attributed artifact:** sha256:301a07d113d1964b69f497b54a8bc32a44f3b8ce0899e03e74809fa660c04067
- **Subject evaluator:** inspect-ai 0.3.254
- **Baseline binding:** sha256:75946ae28ef26de26a8b881c59c041ca0e8e97f60b8849c999ee8bd9c5c8be6e
- **Policy binding:** sha256:2a9ce321ac4690e5e106ac36c4e8e5a6c41c6b7dfb864acd785faa523a2265ff
- **Subject binding:** sha256:d389a09205b5b9ad053ed291e5a4c439404f0d310578cd6cdb9f431a6353721f

## Recorded metric and scope identifiers

```json
[
  {
    "display_metric": "Reference accuracy",
    "display_scope": "overall",
    "metric": "reference_accuracy",
    "result": 1,
    "scope": "overall"
  }
]
```

## Bound policy &#40;configuration preview&#41;

```json
{
  "format": "invarlock/comparison-policy-v1",
  "metrics": [
    {
      "aggregation": "mean",
      "configuration": {
        "limits": {
          "depth": 6,
          "nodes": 128,
          "string_characters": 256
        },
        "note": "Display preview, not a replacement configuration. Full configuration remains in evidence under the original policy binding.",
        "preview_only": true,
        "text": "{}"
      },
      "direction": "higher",
      "kind": "exact_match",
      "maximum_interval_width": 0.1,
      "maximum_regression": 0.02,
      "minimum_count": 64,
      "name": "reference_accuracy",
      "unit": "score"
    }
  ],
  "slices": []
}
```

## Exact comparison data

```json
{
  "bindings": {
    "baseline": "sha256:75946ae28ef26de26a8b881c59c041ca0e8e97f60b8849c999ee8bd9c5c8be6e",
    "policy": "sha256:2a9ce321ac4690e5e106ac36c4e8e5a6c41c6b7dfb864acd785faa523a2265ff",
    "subject": "sha256:d389a09205b5b9ad053ed291e5a4c439404f0d310578cd6cdb9f431a6353721f"
  },
  "decision": "regression",
  "format": "invarlock/multi-metric-comparison-v1",
  "limitations": [
    "Recorded scores retain source judgments; only their aggregation is recomputed.",
    "Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.",
    "Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.",
    "A policy pass does not establish truthful model execution, general quality, safety or compliance."
  ],
  "metrics": [
    {
      "aggregation": "mean",
      "baseline_mean": 0.0,
      "count": 64,
      "decision": "regression",
      "delta": 0.015625,
      "direction": "higher",
      "interval": {
        "lower": -0.04244135214370661,
        "mass": 0.95,
        "method": "newcombe_hybrid_score_paired_v2",
        "replicates": 0,
        "upper": 0.08334101600094264
      },
      "kind": "exact_match",
      "missing_count": 0,
      "missing_ids_preview": [],
      "missing_ids_preview_is_complete": true,
      "name": "reference_accuracy",
      "reasons": [
        "lower interval bound exceeds allowed regression"
      ],
      "scoring_assurance": "recomputed",
      "slice": "overall",
      "subject_mean": 0.015625,
      "unit": "score"
    }
  ]
}
```
