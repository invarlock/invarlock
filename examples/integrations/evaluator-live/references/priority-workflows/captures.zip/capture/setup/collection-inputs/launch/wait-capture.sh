#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
while :; do
 test "$(date +%s)" -lt "$WORK_DEADLINE"
 if /usr/bin/python3 - "$RUNROOT" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);spec=json.loads((p/'inputs/local-64-protocol.json').read_text())
rows=[json.loads(l) for l in (p/'download.jsonl').read_text().splitlines()]
if any(r['status']=='failed' for r in rows):sys.exit(2)
expected={(role,f['path']) for role,m in spec['models'].items() for f in m['files']}
sys.exit(0 if {(r['role'],r['path']) for r in rows}==expected else 1)
PY
 then break; else state=$?; test "$state" -eq 1 || exit "$state"; fi
 sleep 3
done
exec /bin/bash "$(dirname "$0")/capture-all.sh" two
