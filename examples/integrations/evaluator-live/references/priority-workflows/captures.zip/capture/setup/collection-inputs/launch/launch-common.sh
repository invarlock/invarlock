#!/bin/bash
set -euo pipefail
umask 077
RUNROOT=${RUNROOT:-/opt/ivpriority/run}
export RUNROOT
: "${WORK_DEADLINE:?absolute work deadline required}"
: "${HARD_DEADLINE:?absolute rental deadline required}"
[[ "$WORK_DEADLINE" -le $((HARD_DEADLINE - 900)) ]]
[[ "$HARD_DEADLINE" -le $(($(date +%s) + 3600)) ]]
SRC="$RUNROOT/source/examples/integrations/evaluator-live"
PYBOOT=/usr/bin/python3
UV="$RUNROOT/uv"
mkdir -p "$RUNROOT/logs" "$RUNROOT/homes" "$RUNROOT/supervision"
cap() {
  local requested="$1" remaining=$((WORK_DEADLINE - $(date +%s)))
  test "$remaining" -gt 5 || return 124
  if [ "$remaining" -lt "$requested" ]; then printf '%s\n' "$remaining"; else printf '%s\n' "$requested"; fi
}
bounded() {
  local name="$1" seconds="$2"
  shift 2
  mkdir -p "$RUNROOT/homes/$name" "$(dirname "$RUNROOT/logs/$name.time")"
  local launch=()
  if [[ ${OWNED_EXEC:-0} = 1 ]]; then launch=(exec); fi
  "${launch[@]}" "$PYBOOT" "$(dirname "${BASH_SOURCE[0]}")/owned-supervise.py" --seconds "$(cap "$seconds")" \
    --output "$RUNROOT/supervision/$name" -- \
    /usr/bin/time -v -o "$RUNROOT/logs/$name.time" \
    env -i PATH="$RUNROOT/node-v22.22.0-linux-x64/bin:/usr/local/bin:/usr/bin:/bin" \
    HOME="$RUNROOT/homes/$name" XDG_CACHE_HOME="$RUNROOT/homes/$name/.cache" \
    XDG_CONFIG_HOME="$RUNROOT/homes/$name/.config" LANG=C.UTF-8 \
    UV_NO_CONFIG=true UV_CACHE_DIR="$RUNROOT/uv-cache" \
    UV_PYTHON_INSTALL_DIR="$RUNROOT/python" \
    PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
    TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES= \
    HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 \
    "$@"
}

WORKERPY="$RUNROOT/runtime/bin/python"
LOCAL="$RUNROOT/inputs/local-64-protocol.json"
HTTP="$RUNROOT/inputs/http-8-protocol.json"
LOCAL_SHA=sha256:d0caf0bac2d400eb5f9bb008de79d3eefe37a21d1ad14224df89a94c227746fe
HTTP_SHA=sha256:f1d319f8627de1013afd8b5c6f6d99792abbac80b1e5d8dc84e9d4840eff3b70
SDK_NAMES=(inspect-ai lm-evaluation-harness promptfoo langfuse)
mkdir -p -m 700 "$RUNROOT/sockets"

ready() {
  "$PYBOOT" - "$@" "$WORK_DEADLINE" <<'PYREADY'
import hashlib, json, os, pathlib, stat, sys, time
kind, protocol_path, role, output, socket_path, pid, work_deadline = sys.argv[1:]
protocol = json.loads(pathlib.Path(protocol_path).read_text())
raw = (json.dumps({**protocol, "role": role}, sort_keys=True,
       ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode()
expected = "sha256:" + hashlib.sha256(raw).hexdigest()
output = pathlib.Path(output)
channel = pathlib.Path(socket_path)
end = min(time.monotonic() + 180,
          time.monotonic() + max(0, int(work_deadline) - time.time()))
while time.monotonic() < end:
    os.kill(int(pid), 0)  # ProcessLookupError means the owned supervisor exited.
    if (output / "failure.json").exists():
        raise SystemExit("owned process reported failure before readiness")
    marker = output / "ready.json"
    if marker.exists():
        if marker.is_symlink() or not marker.is_file():
            raise SystemExit("readiness marker is not an ordinary file")
        value = json.loads(marker.read_text())
        if kind == "worker":
            if value != {"status": "ready", "protocol_digest": expected}:
                raise SystemExit("worker readiness identity changed")
            mode = channel.lstat().st_mode
            if not stat.S_ISSOCK(mode) or stat.S_IMODE(mode) != 0o600:
                raise SystemExit("worker socket type or permissions changed")
            if stat.S_IMODE(channel.parent.stat().st_mode) != 0o700:
                raise SystemExit("worker socket directory permissions changed")
        elif kind == "service":
            if value != {"endpoint": protocol["http_services"][role]["endpoint"]}:
                raise SystemExit("HTTP service readiness identity changed")
        else:
            raise SystemExit("unknown readiness kind")
        break
    time.sleep(0.2)
else:
    raise SystemExit("readiness deadline exhausted; preserve outputs")
PYREADY
}
