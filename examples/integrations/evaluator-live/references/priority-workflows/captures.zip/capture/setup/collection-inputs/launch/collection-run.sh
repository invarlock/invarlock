#!/bin/bash
# Public-data candidate discovery and review only. Archive is a separate pinned step.
set -euo pipefail
umask 077
RUNROOT=${RUNROOT:-/opt/ivpriority/run}
: "${HARD_DEADLINE:?absolute rental ceiling required}"
HERE=$(cd "$(dirname "$0")" && pwd)
OUT=${1:?new collection output directory outside evidence roots}
shift
mkdir -m 700 "$OUT"
/usr/bin/time -v -o "$OUT/setup-copy.time" /usr/bin/python3 "$HERE/stage-collection-inputs.py" --root "$RUNROOT" --deadline-unix "$HARD_DEADLINE" "$@"
/usr/bin/time -v -o "$OUT/list.time" /usr/bin/python3 "$HERE/collect_results.py" --deadline-unix "$HARD_DEADLINE" list --root "$RUNROOT" --output "$OUT/candidate-files.json" --exclusions "$OUT/exclusions.json"
/usr/bin/time -v -o "$OUT/plan.time" /usr/bin/python3 "$HERE/collect_results.py" --deadline-unix "$HARD_DEADLINE" plan --root "$RUNROOT" --file-list "$OUT/candidate-files.json" --output "$OUT/manifest.json"
sha256sum "$OUT/manifest.json"
printf '%s\n' 'Review candidate-files.json, exclusions.json and manifest.json before the separately pinned archive command. No archive was published by this step.'
