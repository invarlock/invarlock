#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
ROLE=${1:?baseline or subject}
GPU=${2:?GPU index}
STAGE=${3:?local or http}
[[ "$ROLE" = baseline || "$ROLE" = subject ]]
[[ "$GPU" =~ ^[0-9]+$ ]]
OWNED_PIDS=()
cleanup() {
  local status=$?
  trap - EXIT INT TERM
  for pid in "${OWNED_PIDS[@]}"; do kill -TERM "$pid" 2>/dev/null || true; done
  # These are still-unreaped children of this shell, so their PIDs cannot be reused.
  for pid in "${OWNED_PIDS[@]}"; do wait "$pid" 2>/dev/null || true; done
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [[ "$STAGE" = local ]]; then
OWNED_EXEC=1 bounded "worker-local-$ROLE" 900 env CUDA_VISIBLE_DEVICES="$GPU" \
  "$WORKERPY" "$SRC/model_worker.py" --protocol "$LOCAL" --protocol-sha256 "$LOCAL_SHA" \
  --role "$ROLE" --model-dir "$RUNROOT/models/$ROLE" \
  --output "$RUNROOT/worker/local/$ROLE" --socket "$RUNROOT/sockets/local-$ROLE.sock" --execute &
LOCAL_WORKER_PID=$!
OWNED_PIDS+=("$LOCAL_WORKER_PID")
ready worker "$LOCAL" "$ROLE" "$RUNROOT/worker/local/$ROLE" \
  "$RUNROOT/sockets/local-$ROLE.sock" "$LOCAL_WORKER_PID"
for SDK in "${SDK_NAMES[@]}"; do
  test -f "$RUNROOT/sdk/$SDK/ready.json"
  OWNED_EXEC=1 bounded "capture-local-$ROLE-$SDK" 300 \
    env INVARLOCK_PROMPTFOO_PACKAGE="$RUNROOT/sdk/promptfoo/node_modules/promptfoo" \
    "$RUNROOT/sdk/$SDK/venv/bin/python" "$SRC/capture.py" \
    --protocol "$LOCAL" --protocol-sha256 "$LOCAL_SHA" --role "$ROLE" --evaluator "$SDK" \
    --socket "$RUNROOT/sockets/local-$ROLE.sock" --output "$RUNROOT/captures/local/$ROLE/$SDK" &
  CAPTURE_PID=$!; OWNED_PIDS+=("$CAPTURE_PID")
  STATUS=0; wait "$CAPTURE_PID" || STATUS=$?
  OWNED_PIDS=("$LOCAL_WORKER_PID")
  [[ "$STATUS" = 0 ]]
done
STATUS=0; wait "$LOCAL_WORKER_PID" || STATUS=$?
OWNED_PIDS=()
[[ "$STATUS" = 0 ]]

elif [[ "$STAGE" = http ]]; then
OWNED_EXEC=1 bounded "worker-http-$ROLE" 600 env CUDA_VISIBLE_DEVICES="$GPU" \
  "$WORKERPY" "$SRC/model_worker.py" --protocol "$HTTP" --protocol-sha256 "$HTTP_SHA" \
  --role "$ROLE" --model-dir "$RUNROOT/models/$ROLE" \
  --output "$RUNROOT/worker/http/$ROLE" --socket "$RUNROOT/sockets/http-$ROLE.sock" --execute &
HTTP_WORKER_PID=$!
OWNED_PIDS+=("$HTTP_WORKER_PID")
ready worker "$HTTP" "$ROLE" "$RUNROOT/worker/http/$ROLE" \
  "$RUNROOT/sockets/http-$ROLE.sock" "$HTTP_WORKER_PID"
OWNED_EXEC=1 bounded "service-http-$ROLE" 600 "$WORKERPY" "$SRC/http_service.py" \
  --protocol "$HTTP" --protocol-sha256 "$HTTP_SHA" --role "$ROLE" \
  --socket "$RUNROOT/sockets/http-$ROLE.sock" --output "$RUNROOT/service/$ROLE" &
HTTP_SERVICE_PID=$!
OWNED_PIDS+=("$HTTP_SERVICE_PID")
ready service "$HTTP" "$ROLE" "$RUNROOT/service/$ROLE" \
  "$RUNROOT/sockets/http-$ROLE.sock" "$HTTP_SERVICE_PID"
for SDK in "${SDK_NAMES[@]}"; do
  OWNED_EXEC=1 bounded "capture-http-$ROLE-$SDK" 180 \
    env INVARLOCK_PROMPTFOO_PACKAGE="$RUNROOT/sdk/promptfoo/node_modules/promptfoo" \
    "$RUNROOT/sdk/$SDK/venv/bin/python" "$SRC/capture.py" \
    --protocol "$HTTP" --protocol-sha256 "$HTTP_SHA" --role "$ROLE" --evaluator "$SDK" \
    --output "$RUNROOT/captures/http/$ROLE/$SDK" &
  CAPTURE_PID=$!; OWNED_PIDS+=("$CAPTURE_PID")
  STATUS=0; wait "$CAPTURE_PID" || STATUS=$?
  OWNED_PIDS=("$HTTP_WORKER_PID" "$HTTP_SERVICE_PID")
  [[ "$STATUS" = 0 ]]
done
STATUS=0; wait "$HTTP_SERVICE_PID" || STATUS=$?
OWNED_PIDS=("$HTTP_WORKER_PID")
[[ "$STATUS" = 0 ]]
STATUS=0; wait "$HTTP_WORKER_PID" || STATUS=$?
OWNED_PIDS=()
[[ "$STATUS" = 0 ]]

else
  exit 2
fi
