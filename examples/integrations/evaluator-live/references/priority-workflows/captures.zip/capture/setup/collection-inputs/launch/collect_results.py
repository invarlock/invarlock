#!/usr/bin/env python3
"""Private public-data collector: review a file list, pin it, archive, verify."""
import argparse
import hashlib
import json
import io
import os
from pathlib import Path, PurePosixPath
import re
import signal
import stat
import time
import zipfile

MAX_FILE = 64 * 1024**2
MAX_TOTAL = 512 * 1024**2
MAX_COUNT = 20000
ROOTS = {'captures', 'worker', 'service', 'preflight', 'supervision', 'logs',
         'indexes', 'inputs', 'recipients', 'retained-source', 'setup'}
SUFFIXES = {'.json', '.jsonl', '.ndjson', '.log', '.txt', '.time', '.md', '.html',
            '.py', '.sh', '.js', '.mjs', '.ts', '.yaml', '.yml', '.csv', '.eval', '.xml'}
FORBIDDEN = {'models', 'runtime', 'recipient', 'venv', '.venv', 'node_modules',
             'homes', '.cache', '.config', '.git', '__pycache__', 'uv-cache',
             'credentials', 'authorization', 'authorizations'}
SECRETS = re.compile(rb'-----BEGIN (?:[A-Z0-9 ]*PRIVATE KEY)-----|'
                     rb'\b(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{16,}|hf_[A-Za-z0-9]{20,})\b|'
                     rb'(?i:["\x27](?:api[_-]?key|access[_-]?token|refresh[_-]?token|'
                     rb'client[_-]?secret|password)["\x27]\s*:\s*["\x27][^"\x27]+["\x27])')


def safe_name(name):
    path = PurePosixPath(name)
    if (not isinstance(name, str) or '\\' in name or ':' in name or '\x00' in name or
            path.is_absolute() or str(path) != name or any(p in ('', '.', '..') for p in path.parts)):
        raise ValueError('unsafe archive member name')
    if not path.parts or path.parts[0] not in ROOTS:
        raise ValueError('file outside explicitly permitted evidence roots')
    if any(p.lower() in FORBIDDEN or p.lower().endswith(('.pem', '.key', '.env')) or
           'authorization' in p.lower() or 'credential' in p.lower() for p in path.parts):
        raise ValueError('private or environment file is excluded')
    if path.suffix.lower() not in SUFFIXES:
        raise ValueError('file type requires explicit review; not collected automatically')
    return path


def read_public(root, name):
    relative = safe_name(name)
    path = root
    for part in relative.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError('symlink in retained path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
            raise ValueError('nonregular or oversized retained file')
        data = stream.read(MAX_FILE + 1)
        if len(data) > MAX_FILE:
            raise ValueError('retained file grew beyond bound')
    inspect_content(name, data)
    return data


def inspect_content(name, data):
    if SECRETS.search(data):
        raise ValueError('possible credential or private key in retained file')
    if data.startswith(b'PK'):
        if not name.endswith('.eval'):
            raise ValueError('nested archive requires explicit review')
        # Inspect's native .eval log is a ZIP of JSON files, never opaque blobs.
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            entries = archive.infolist()
            names = [e.filename for e in entries]
            if len(names) != len(set(names)) or len(names) > MAX_COUNT or sum(e.file_size for e in entries) > MAX_FILE:
                raise ValueError('oversized or duplicate native log inventory')
            for entry in entries:
                path = PurePosixPath(entry.filename)
                if (path.is_absolute() or str(path) != entry.filename or ':' in entry.filename or
                        '\\' in entry.filename or '..' in path.parts or path.suffix != '.json' or
                        entry.file_size > MAX_FILE or stat.S_ISLNK(entry.external_attr >> 16)):
                    raise ValueError('unsafe native log member')
                body = archive.read(entry)
                json.loads(body)
                if SECRETS.search(body):
                    raise ValueError('possible secret in compressed native log')
    elif name.endswith('.eval'):
        raise ValueError('unknown native log encoding')


def fact(data):
    return {'byte_size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def plan(root, names):
    if not isinstance(names, list) or not names or len(names) > MAX_COUNT:
        raise ValueError('declare a bounded nonempty explicit file list')
    if any(not isinstance(x, str) for x in names) or len(set(names)) != len(names):
        raise ValueError('duplicate or nonstring retained path')
    members = {}
    for name in sorted(names):
        members[name] = fact(read_public(root, name))
        if sum(f['byte_size'] for f in members.values()) > MAX_TOTAL:
            raise ValueError('collection exceeds expanded bound')
    return {'format': 'priority-qualification-collection-v1', 'members': members}


def validate_manifest(value):
    if set(value) != {'format', 'members'} or value['format'] != 'priority-qualification-collection-v1':
        raise ValueError('invalid collection manifest')
    members = value['members']
    if not isinstance(members, dict) or not 0 < len(members) <= MAX_COUNT:
        raise ValueError('invalid member inventory')
    total = 0
    for name, value in members.items():
        safe_name(name)
        if (set(value) != {'byte_size', 'sha256'} or type(value['byte_size']) is not int or
                not 0 <= value['byte_size'] <= MAX_FILE or
                not re.fullmatch('[0-9a-f]{64}', value['sha256'])):
            raise ValueError('invalid member fact')
        total += value['byte_size']
    if total > MAX_TOTAL:
        raise ValueError('expanded collection bound exceeded')
    return members


def create(root, manifest, destination):
    members = validate_manifest(manifest)
    if destination.exists() or destination.is_symlink():
        raise ValueError('archive destination already exists')
    partial = destination.with_name(destination.name + '.part')
    with partial.open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
            for name, expected in [('collection-manifest.json', fact(encode(manifest))), *members.items()]:
                data = encode(manifest) if name == 'collection-manifest.json' else read_public(root, name)
                if fact(data) != expected:
                    raise ValueError('file changed after collection review')
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data, compresslevel=1)
                if stream.tell() > MAX_TOTAL + 8 * 1024**2:
                    raise ValueError('archive physical size bound exceeded')
        stream.flush()
        os.fsync(stream.fileno())
    os.link(partial, destination)
    partial.unlink()
    return fact(destination.read_bytes())


def verify(path, expected):
    if path.is_symlink() or path.stat().st_size > MAX_TOTAL + 8 * 1024**2:
        raise ValueError('unsafe or oversized archive')
    raw = path.read_bytes()
    if len(raw) > MAX_TOTAL + 8 * 1024**2:
        raise ValueError('archive grew beyond physical bound')
    if hashlib.sha256(raw).hexdigest() != expected.removeprefix('sha256:'):
        raise ValueError('archive hash differs from independent transfer pin')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        if (len(names) != len(set(names)) or len(names) > MAX_COUNT + 1 or
                sum(i.file_size for i in infos) > MAX_TOTAL + 8 * 1024**2):
            raise ValueError('duplicate or oversized archive inventory')
        for info in infos:
            if info.filename != 'collection-manifest.json':
                safe_name(info.filename)
            if not stat.S_ISREG(info.external_attr >> 16) or info.file_size > MAX_FILE:
                raise ValueError('nonregular or oversized archive member')
        manifest = json.loads(archive.read('collection-manifest.json'))
        members = validate_manifest(manifest)
        if set(names) != set(members) | {'collection-manifest.json'}:
            raise ValueError('archive inventory differs from manifest')
        for name, expected_fact in members.items():
            data = archive.read(name)  # ZIP CRC also checked here; never extract/execute.
            if fact(data) != expected_fact:
                raise ValueError('archive member changed')
            inspect_content(name, data)
    return {'status': 'verified', 'archive': fact(raw), 'members': len(members),
            'expanded_bytes': sum(v['byte_size'] for v in members.values())}


def candidates(root):
    names, excluded = [], []
    for prefix in sorted(ROOTS):
        directory = root / prefix
        if not directory.exists():
            continue
        if directory.is_symlink():
            excluded.append({'path': prefix, 'reason': 'symlink root'})
            continue
        for parent, dirs, files in os.walk(directory, followlinks=False):
            kept = []
            for name in dirs:
                path = Path(parent) / name
                if path.is_symlink() or name.lower() in FORBIDDEN:
                    excluded.append({'path': path.relative_to(root).as_posix(), 'reason': 'excluded directory'})
                else:
                    kept.append(name)
            dirs[:] = kept
            for filename in files:
                path = Path(parent) / filename
                name = path.relative_to(root).as_posix()
                try:
                    read_public(root, name)
                except (ValueError, OSError, zipfile.BadZipFile) as exc:
                    excluded.append({'path': name, 'reason': type(exc).__name__})
                else:
                    names.append(name)
                if len(names) + len(excluded) > MAX_COUNT:
                    raise ValueError('candidate inventory exceeds count bound')
    return sorted(names), excluded


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deadline-unix', type=int, required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    listing = commands.add_parser('list')
    listing.add_argument('--root', type=Path, required=True)
    listing.add_argument('--output', type=Path, required=True)
    listing.add_argument('--exclusions', type=Path, required=True)
    draft = commands.add_parser('plan')
    draft.add_argument('--root', type=Path, required=True)
    draft.add_argument('--file-list', type=Path, required=True)
    draft.add_argument('--output', type=Path, required=True)
    pack = commands.add_parser('archive')
    pack.add_argument('--root', type=Path, required=True)
    pack.add_argument('--manifest', type=Path, required=True)
    pack.add_argument('--manifest-sha256', required=True)
    pack.add_argument('--output', type=Path, required=True)
    check = commands.add_parser('verify')
    check.add_argument('--archive', type=Path, required=True)
    check.add_argument('--archive-sha256', required=True)
    args = parser.parse_args()
    remaining = args.deadline_unix-time.time()
    if not 0 < remaining <= 3600:
        raise ValueError('collection requires a current deadline within one hour')
    def expired(*_):
        raise TimeoutError('absolute collection deadline exhausted')
    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, remaining)
    if args.command == 'list':
        names, exclusions = candidates(args.root.resolve(strict=True))
        for path, value in [(args.output, names), (args.exclusions, exclusions)]:
            with path.open('xb') as stream:
                stream.write(encode(value))
        print(json.dumps({'candidate_files': len(names), 'excluded_entries': len(exclusions), 'review_required': True}))
    elif args.command == 'plan':
        result = plan(args.root.resolve(strict=True), json.loads(args.file_list.read_bytes()))
        with args.output.open('xb') as output:
            output.write(encode(result))
        print(json.dumps(fact(encode(result))))
    elif args.command == 'archive':
        raw = args.manifest.read_bytes()
        if hashlib.sha256(raw).hexdigest() != args.manifest_sha256.removeprefix('sha256:'):
            raise ValueError('reviewed manifest pin changed')
        print(json.dumps(create(args.root.resolve(strict=True), json.loads(raw), args.output)))
    else:
        print(json.dumps(verify(args.archive, args.archive_sha256)))
    signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
