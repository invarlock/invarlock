#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
for ROLE in baseline subject; do
  bounded "preflight-local-$ROLE" 180 "$WORKERPY" "$SRC/model_worker.py" \
    --protocol "$LOCAL" --protocol-sha256 "$LOCAL_SHA" --role "$ROLE" \
    --model-dir "$RUNROOT/models/$ROLE" --output "$RUNROOT/preflight/local/$ROLE" \
    --socket "$RUNROOT/sockets/preflight-$ROLE.sock" --preflight
  bounded "preflight-http-$ROLE" 180 "$WORKERPY" "$SRC/model_worker.py" \
    --protocol "$HTTP" --protocol-sha256 "$HTTP_SHA" --role "$ROLE" \
    --model-dir "$RUNROOT/models/$ROLE" --output "$RUNROOT/preflight/http/$ROLE" \
    --socket "$RUNROOT/sockets/preflight-http-$ROLE.sock" --preflight
done

"$PYBOOT" - "$RUNROOT" <<'PYCHECK'
import json,sys
from pathlib import Path
for stage,count in [('local',64),('http',8)]:
 for role in ('baseline','subject'):
  value=json.loads((Path(sys.argv[1])/'preflight'/stage/role/'preflight.json').read_bytes())
  assert value=={'status':'tokenization_only','model_loaded':False,'inference_calls':0,'case_count':count}
PYCHECK
