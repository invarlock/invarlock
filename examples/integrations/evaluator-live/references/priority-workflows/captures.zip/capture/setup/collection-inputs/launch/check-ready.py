#!/usr/bin/env python3
import argparse, hashlib, importlib.metadata, json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--sdk',required=True);p.add_argument('--root',type=Path,required=True);a=p.parse_args()
versions={'inspect-ai':('inspect-ai','0.3.254'),'lm-evaluation-harness':('lm-eval','0.4.12'),'langfuse':('langfuse','4.14.1')}
if a.sdk=='runtime':
 expected={'torch':'2.13.0+cu130','transformers':'5.14.1','lm-eval':'0.4.12','accelerate':'1.14.0+invarlock.1','tokenizers':'0.22.2','sentencepiece':'0.2.2'}
 actual={k:importlib.metadata.version(k) for k in expected}
 assert actual==expected,(actual,expected)
 target=a.root/'runtime-ready.json'
elif a.sdk=='promptfoo':
 actual=json.loads((a.root/'sdk/promptfoo/node_modules/promptfoo/package.json').read_text())['version'];assert actual=='0.121.19';target=a.root/'sdk/promptfoo/ready.json'
else:
 name,version=versions[a.sdk];actual=importlib.metadata.version(name);assert actual==version;target=a.root/'sdk'/a.sdk/'ready.json'
with target.open('x') as out:json.dump({'status':'ready','sdk':a.sdk,'version':actual},out)
