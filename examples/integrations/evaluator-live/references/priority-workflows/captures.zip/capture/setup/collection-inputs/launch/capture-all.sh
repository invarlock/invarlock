#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
GPUS=${1:?one or two}
[[ "$GPUS" = one || "$GPUS" = two ]]
HERE=$(cd "$(dirname "$0")" && pwd)
test -f "$RUNROOT/runtime-ready.json"
for SDK in "${SDK_NAMES[@]}"; do test -f "$RUNROOT/sdk/$SDK/ready.json"; done
bash "$HERE/preflight-run.sh"
for STAGE in local http; do
  if [[ "$GPUS" = two ]]; then
    bash "$HERE/capture-role.sh" baseline 0 "$STAGE" & B=$!
    bash "$HERE/capture-role.sh" subject 1 "$STAGE" & S=$!
    BSTATUS=0; SSTATUS=0
    wait "$B" || BSTATUS=$?
    wait "$S" || SSTATUS=$?
    [[ "$BSTATUS" = 0 && "$SSTATUS" = 0 ]] || exit 1
  else
    bash "$HERE/capture-role.sh" baseline 0 "$STAGE"
    bash "$HERE/capture-role.sh" subject 0 "$STAGE"
  fi
  "$PYBOOT" "$HERE/check-stage.py" --root "$RUNROOT" --stage "$STAGE"
done
