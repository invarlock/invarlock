#!/usr/bin/env python3
"""Check completion and file pins without inventing recipient acceptance."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--stage',choices=['local','http'],required=True);a=p.parse_args()
def read(path):return json.loads(path.read_bytes())
def digest(value):return 'sha256:'+hashlib.sha256((json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
protocol=read(a.root/'inputs'/('local-64-protocol.json' if a.stage=='local' else 'http-8-protocol.json'))
versions={'inspect-ai':'0.3.254','lm-evaluation-harness':'0.4.12','promptfoo':'0.121.19','langfuse':'4.14.1'}
count=64 if a.stage=='local' else 8
assert len(protocol['cases'])==count
index={}; inventory={}
for role in ('baseline','subject'):
 completion=read(a.root/'worker'/a.stage/role/'complete.json')
 assert completion['status']=='complete' and completion['admitted_requests']==count*4
 if a.stage=='http':
  completion=read(a.root/'service'/role/'complete.json');assert completion=={'status':'complete','requests':count*4}
 for sdk,version in versions.items():
  directory=a.root/'captures'/a.stage/role/sdk; m=read(directory/'capture.json')
  assert (m['status'],m['evaluator'],m['version'],m['role'],m['case_count'],m['protocol_digest'])==('captured',sdk,version,role,count,digest({**protocol,'role':role}))
  assert m['native_sha256']=='sha256:'+hashlib.sha256((directory/'native.json').read_bytes()).hexdigest()
  if a.stage=='http':assert m['native_original_sha256']=='sha256:'+hashlib.sha256((directory/'native-original.json').read_bytes()).hexdigest()
  assert len(list((directory/'tasks').glob('*.response.json')))==count
  assert len(list((directory/'tasks').glob('*.request.json')))==count
  index.setdefault(sdk,{})[role]=str(directory)
  for name in ['capture.json','protocol.json','native.json']+(['native-original.json'] if a.stage=='http' else []):
   data=(directory/name).read_bytes();inventory[(directory/name).relative_to(a.root).as_posix()]={'sha256':hashlib.sha256(data).hexdigest(),'byte_size':len(data)}
output=a.root/'indexes';output.mkdir(exist_ok=True)
for name,value in [(a.stage+'.json',index),(a.stage+'-relative.json',{sdk:{role:str(Path(path).relative_to(a.root)) for role,path in roles.items()} for sdk,roles in index.items()}),(a.stage+'-inventory.json',inventory)]:
 with (output/name).open('x') as f:json.dump(value,f,sort_keys=True,indent=2)
print(json.dumps({'status':'capture_files_complete','stage':a.stage,'pairs':len(index),'case_requests':count*8,'recipient_verification':'pending'}))
