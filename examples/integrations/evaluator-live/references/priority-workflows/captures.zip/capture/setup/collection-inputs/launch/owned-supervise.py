#!/usr/bin/env python3
"""Private launcher: retain maintained process-group cleanup on TERM/INT."""
import json
import os
from pathlib import Path
import signal
import sys

source=Path(os.environ['RUNROOT'])/'source/examples/integrations/evaluator-live'
sys.path.insert(0,str(source))
import supervise

def interrupted(signum, frame):
    raise SystemExit(128+signum)

signal.signal(signal.SIGTERM,interrupted)
signal.signal(signal.SIGINT,interrupted)
try:
    supervise.main()
except SystemExit as exc:
    # Maintained run() finally has already killed/waited its exact command group.
    if isinstance(exc.code,int) and exc.code in (130,143):
        arguments=sys.argv[1:]
        if '--output' in arguments:
            output=Path(arguments[arguments.index('--output')+1])
            result=output/'result.json'
            if output.is_dir() and not result.exists():
                with result.open('x') as stream:
                    json.dump({'exit_code':exc.code,'interrupted':True,
                               'scope':'owned supervisor command group'},stream)
    raise
