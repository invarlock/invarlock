#!/usr/bin/env python3
import base64,hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); value=json.loads((root/'pack.json').read_bytes())
assert len(value)==1 and value[0]['filename']=='promptfoo-0.121.19.tgz'
payload=(root/value[0]['filename']).read_bytes()
assert hashlib.sha1(payload).hexdigest()=='544bf866ac349ea51566186bf8f272d041a30431'
assert base64.b64encode(hashlib.sha512(payload).digest()).decode()=='5YebsCED/bmR9JktH9YNU62Tr1m3ncFMlM2tKrguI8vFFUfvqxhNzUBa3Z6huG7OvDKbi69UpamU4CLtYLDezQ=='
print('Pinned Promptfoo archive verified')
