#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
HERE=$(cd "$(dirname "$0")" && pwd)
test -x "$UV"
bounded freeze-normalization 60 "$PYBOOT" "$HERE/normalize-freeze.py" --inputs "$RUNROOT/inputs"
bounded python-setup 300 "$UV" python install 3.12.13
runtime_setup() {
 bounded runtime-create 120 "$UV" venv --python 3.12.13 "$RUNROOT/runtime"
 bounded accelerate-build 120 "$RUNROOT/runtime/bin/python" "$RUNROOT/source/scripts/security/build_hardened_accelerate_wheel.py" bootstrap --output-directory "$RUNROOT/runtime-wheels"
 bounded runtime-install 900 "$UV" pip install --python "$RUNROOT/runtime/bin/python" --find-links "$RUNROOT/runtime-wheels" --extra-index-url https://download.pytorch.org/whl/cu130 -r "$RUNROOT/inputs/runtime-linux-freeze.txt"
 bounded runtime-check 120 "$UV" pip check --python "$RUNROOT/runtime/bin/python"
 bounded runtime-inventory 120 "$UV" pip freeze --python "$RUNROOT/runtime/bin/python"
 bounded runtime-ready 60 "$RUNROOT/runtime/bin/python" "$HERE/check-ready.py" --sdk runtime --root "$RUNROOT"
}
sdk_setup() {
 for SDK in inspect-ai lm-evaluation-harness langfuse; do
  bounded "$SDK-create" 120 "$UV" venv --python 3.12.13 "$RUNROOT/sdk/$SDK/venv"
  bounded "$SDK-install" 600 "$UV" pip install --python "$RUNROOT/sdk/$SDK/venv/bin/python" -r "$RUNROOT/inputs/$SDK-requirements.txt"
  bounded "$SDK-check" 120 "$UV" pip check --python "$RUNROOT/sdk/$SDK/venv/bin/python"
  bounded "$SDK-inventory" 120 "$UV" pip freeze --python "$RUNROOT/sdk/$SDK/venv/bin/python"
  bounded "$SDK-ready" 60 "$RUNROOT/sdk/$SDK/venv/bin/python" "$HERE/check-ready.py" --sdk "$SDK" --root "$RUNROOT"
 done
}
node_setup() {
 bounded promptfoo-python 120 "$UV" venv --python 3.12.13 "$RUNROOT/sdk/promptfoo/venv"
 bounded node-download 120 /usr/bin/curl -q --fail --location --proto '=https' --proto-redir '=https' --max-time 90 --max-filesize 67108864 https://nodejs.org/dist/v22.22.0/node-v22.22.0-linux-x64.tar.xz --output "$RUNROOT/node.tar.xz"
 printf '%s  %s\n' 9aa8e9d2298ab68c600bd6fb86a6c13bce11a4eca1ba9b39d79fa021755d7c37 "$RUNROOT/node.tar.xz" | sha256sum --check
 bounded node-unpack 60 /usr/bin/tar -xJf "$RUNROOT/node.tar.xz" -C "$RUNROOT"
 bounded promptfoo-pack 180 /bin/bash -c 'cd "$1"; npm pack promptfoo@0.121.19 --json > pack.json 2> pack.stderr.log' bash "$RUNROOT/sdk/promptfoo"
 "$PYBOOT" "$HERE/verify-promptfoo.py" "$RUNROOT/sdk/promptfoo"
 bounded promptfoo-install 300 npm install --prefix "$RUNROOT/sdk/promptfoo" --ignore-scripts --no-audit --no-fund "$RUNROOT/sdk/promptfoo/promptfoo-0.121.19.tgz"
 bounded promptfoo-inventory 120 npm ls --prefix "$RUNROOT/sdk/promptfoo" --all --json
 bounded promptfoo-ready 60 "$RUNROOT/sdk/promptfoo/venv/bin/python" "$HERE/check-ready.py" --sdk promptfoo --root "$RUNROOT"
}
runtime_setup & R=$!
sdk_setup & S=$!
node_setup & N=$!
RSTATUS=0; SSTATUS=0; NSTATUS=0
wait "$R" || RSTATUS=$?
wait "$S" || SSTATUS=$?
wait "$N" || NSTATUS=$?
[[ "$RSTATUS" = 0 && "$SSTATUS" = 0 && "$NSTATUS" = 0 ]]
