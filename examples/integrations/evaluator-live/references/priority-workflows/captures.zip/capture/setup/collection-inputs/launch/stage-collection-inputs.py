#!/usr/bin/env python3
"""Copy only declared public setup/source facts into collector-permitted roots."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import time

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('collection_filter',HERE/'collect_results.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)


def stage(root, extra=()):
    target=root/'setup'/'collection-inputs'
    target.mkdir(parents=True,exist_ok=False,mode=0o700)
    copied=[];missing=[]
    def copy(relative,destination,required=False):
        path=root
        for part in Path(relative).parts:
            path=path/part
            if path.is_symlink():raise ValueError('symlink in declared setup source')
        if not path.exists():
            if required:raise ValueError('required setup source missing: '+relative)
            missing.append(relative);return
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as stream:
            info=os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size>C.MAX_FILE:raise ValueError('invalid setup source')
            data=stream.read(C.MAX_FILE+1)
            if len(data)>C.MAX_FILE:raise ValueError('setup source exceeds bound')
        C.safe_name(destination.relative_to(root).as_posix())
        C.inspect_content(destination.name,data)
        destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.open('xb') as stream:stream.write(data)
        copied.append({'original_path':relative,'retained_path':destination.relative_to(root).as_posix(),
                       'sha256':hashlib.sha256(data).hexdigest(),'byte_size':len(data)})
    roots=['runtime-ready.json','uv-install.json','uv-provenance.json','source-provenance.json',
           'download_models.py',
           'download.jsonl','model-download.jsonl','download-manifest.json']
    for name in extra:
        if Path(name).name!=name or ':' in name or '\\' in name:raise ValueError('extra setup file must be root basename')
        C.safe_name('setup/'+name)
        if name not in roots:roots.append(name)
    for name in roots:copy(name,target/'root-files'/name,required=name=='runtime-ready.json' or name in extra)
    launch=root/'launch'
    for name in ['launch-common.sh','setup-run.sh','normalize-freeze.py','check-ready.py',
                 'verify-promptfoo.py','capture-all.sh','capture-role.sh','preflight-run.sh',
                 'check-stage.py','owned-supervise.py','download_models.py','collect_results.py',
                 'collection-run.sh','stage-collection-inputs.py','runtime-recovery.sh','wait-capture.sh']:
        copy('launch/'+name,target/'launch'/name)
    for sdk in ('inspect-ai','lm-evaluation-harness','promptfoo','langfuse'):
        copy(f'sdk/{sdk}/ready.json',target/'sdk'/sdk/'ready.json',required=True)
    copy('sdk/promptfoo/package-lock.json',target/'sdk/promptfoo/package-lock.json',required=True)
    for name in ('pack.json','pack.stderr.log'):
        copy('sdk/promptfoo/'+name,target/'sdk/promptfoo'/name)
    src=root/'source/examples/integrations/evaluator-live'
    if not src.is_dir() or src.is_symlink():raise ValueError('frozen source helpers missing')
    for path in sorted(src.glob('*.py')):
        relative=path.relative_to(root).as_posix()
        copy(relative,root/'retained-source'/path.relative_to(root/'source'),required=True)
    for name in ['examples/captured-results/harness_model_comparison.py',
                 'examples/evaluator-qualification/matrix.json',
                 'scripts/security/build_hardened_accelerate_wheel.py',
                 'scripts/security/build_cache_free_lm_eval_wheel.py',
                 'examples/evaluator-qualification/locks/promptfoo.txt']:
        copy('source/'+name,root/'retained-source'/name,required=True)
    manifest={'format':'priority-setup-retention-v1','copied':copied,'optional_files_absent':missing,
              'source_bytes':'copied unchanged; paths mapped explicitly; no source execution'}
    with (target/'copy-manifest.json').open('x') as stream:json.dump(manifest,stream,sort_keys=True,indent=2)
    return manifest


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--deadline-unix',type=int,required=True);p.add_argument('--extra-root-file',action='append',default=[]);a=p.parse_args()
    remaining=a.deadline_unix-time.time()
    if not 0<remaining<=3600:raise ValueError('absolute collection deadline invalid')
    def expired(*_):raise TimeoutError('setup retention deadline exhausted')
    signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,remaining)
    result=stage(a.root.resolve(strict=True),a.extra_root_file)
    print(json.dumps({'copied':len(result['copied']),'optional_files_absent':result['optional_files_absent']}))
    signal.setitimer(signal.ITIMER_REAL,0)

if __name__=='__main__':main()
