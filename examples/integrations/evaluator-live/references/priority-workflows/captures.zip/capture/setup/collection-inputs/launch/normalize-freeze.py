#!/usr/bin/env python3
import argparse,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);a=p.parse_args()
expected={'inspect-ai':'637ca768bd1e6a1be305c04c4e430c23f29fbb6440cda1b839cb1a6ff7b7edb8','lm-evaluation-harness':'413fa13c7560c5bce13ddb7a3acee2161274e563033a0389a0fff1938fa505bb','langfuse':'4c16aed4088f07fc1142e7e1c04532ebb3333a13073a76f9aa76cd32155f2a38'}
for sdk,pin in expected.items():
 src=a.inputs/f'{sdk}-linux-freeze.txt';raw=src.read_bytes();assert hashlib.sha256(raw).hexdigest()==pin
 lines=raw.decode().splitlines();header=f'Using Python 3.12.13 environment at: sdk/environments/{sdk}/venv'
 assert lines[0]==header
 packages=lines[1:];assert packages and all(re.fullmatch(r'[a-zA-Z0-9_.-]+==[a-zA-Z0-9_.+!-]+',line) for line in packages)
 assert len({line.split('==')[0].lower() for line in packages})==len(packages)
 dst=a.inputs/f'{sdk}-requirements.txt';data=('\n'.join(packages)+'\n').encode()
 with dst.open('xb') as stream:stream.write(data)
 print(json.dumps({'source':src.name,'source_sha256':pin,'derived':dst.name,'sha256':hashlib.sha256(data).hexdigest(),'removed_exact_first_line':header}))
