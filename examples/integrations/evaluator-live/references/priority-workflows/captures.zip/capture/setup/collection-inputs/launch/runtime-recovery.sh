#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/launch-common.sh"
HERE=$(cd "$(dirname "$0")" && pwd)
bounded runtime-torch-install 900 "$UV" pip install --python "$RUNROOT/runtime/bin/python" 'torch==2.13.0+cu130' --index-url https://download.pytorch.org/whl/cu130
bounded runtime-install-pypi 900 "$UV" pip install --python "$RUNROOT/runtime/bin/python" --find-links "$RUNROOT/runtime-wheels" -r "$RUNROOT/inputs/runtime-linux-freeze.txt"
bounded runtime-check-final 120 "$UV" pip check --python "$RUNROOT/runtime/bin/python"
bounded runtime-inventory-final 120 "$UV" pip freeze --python "$RUNROOT/runtime/bin/python"
bounded runtime-ready-final 60 "$RUNROOT/runtime/bin/python" "$HERE/check-ready.py" --sdk runtime --root "$RUNROOT"
