#!/usr/bin/env python3
"""Private campaign setup: download only independently pinned public model files."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import time
import urllib.parse
import urllib.request

PINS = {
    'd0caf0bac2d400eb5f9bb008de79d3eefe37a21d1ad14224df89a94c227746fe',
    'f1d319f8627de1013afd8b5c6f6d99792abbac80b1e5d8dc84e9d4840eff3b70',
}
MODELS = {
    'baseline': ('mistralai/Mistral-7B-v0.1', '27d67f1b5f57dc0953326b2601d68371d40ea8da'),
    'subject': ('mistralai/Mistral-7B-Instruct-v0.1', 'ec5deb64f2c6e6fa90c1abf74a91d5c93a9669ca'),
}
BLOCK = 8 * 1024 * 1024


def check_time(deadline):
    if time.time() >= deadline:
        raise TimeoutError('absolute download deadline exhausted')


def regular(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('expected ordinary file')


def facts(protocol):
    if set(protocol['models']) != set(MODELS):
        raise ValueError('model roles changed')
    result = []
    for role, model in protocol['models'].items():
        if (model['id'], model['revision']) != MODELS[role]:
            raise ValueError('public model identity changed')
        seen = set()
        for fact in model['files']:
            name = fact['path']
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', name) or name in seen:
                raise ValueError('unsafe or duplicate model filename')
            seen.add(name)
            if type(fact['byte_size']) is not int or not 0 < fact['byte_size'] <= 16 * 1024**3:
                raise ValueError('invalid file size')
            if not re.fullmatch(r'sha256:[0-9a-f]{64}', fact['sha256']):
                raise ValueError('invalid file digest')
            url = f"https://huggingface.co/{model['id']}/resolve/{model['revision']}/{name}"
            result.append((role, fact, url))
    return result


def hash_file(path, deadline):
    regular(path)
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        while block := stream.read(BLOCK):
            check_time(deadline)
            digest.update(block)
            size += len(block)
    return size, 'sha256:' + digest.hexdigest()


def https_url(url):
    value = urllib.parse.urlsplit(url)
    host = value.hostname or ''
    if (value.scheme != 'https' or value.username or value.password or
            value.port not in (None, 443) or not any(
                host == suffix or host.endswith('.' + suffix)
                for suffix in ('huggingface.co', 'hf.co', 'cloudfront.net'))):
        raise ValueError('download redirect outside approved public HTTPS hosts')
    return url


class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return super().redirect_request(req, fp, code, msg, headers, https_url(newurl))


def fetch(path, fact, url, deadline, opener):
    check_time(deadline)
    if path.exists() or path.is_symlink():
        size, digest = hash_file(path, deadline)
        state = 'verified_existing'
    else:
        part = path.with_name(path.name + '.part')
        digest, size = hashlib.sha256(), 0
        # Exclusive partial file retains interrupted or failed downloads for diagnosis.
        with part.open('xb') as output:
            with opener.open(https_url(url), timeout=min(30, max(0.1, deadline-time.time()))) as response:
                while block := response.read(BLOCK):
                    check_time(deadline)
                    size += len(block)
                    if size > fact['byte_size']:
                        raise ValueError('download exceeded pinned byte size')
                    digest.update(block)
                    output.write(block)
            output.flush()
            os.fsync(output.fileno())
        digest = 'sha256:' + digest.hexdigest()
        if (size, digest) != (fact['byte_size'], fact['sha256']):
            raise ValueError('download differs from independently pinned file')
        # No replacement of an existing destination, even in a race.
        os.link(part, path)
        part.unlink()
        state = 'downloaded_verified'
    if (size, digest) != (fact['byte_size'], fact['sha256']):
        raise ValueError('existing file differs from independently pinned file')
    return {'path': path.name, 'url': url, 'byte_size': size, 'sha256': digest, 'status': state}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--protocol-sha256', required=True)
    parser.add_argument('--models', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--deadline-unix', type=int, required=True)
    args = parser.parse_args()
    check_time(args.deadline_unix)
    def expired(*_):
        raise TimeoutError('absolute download deadline exhausted')
    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, args.deadline_unix-time.time())
    raw = args.protocol.read_bytes()
    expected = args.protocol_sha256.removeprefix('sha256:')
    if expected not in PINS or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('protocol is not an independently pinned campaign input')
    inventory = facts(json.loads(raw))
    args.models.mkdir(mode=0o700, parents=True, exist_ok=True)
    if args.models.is_symlink():
        raise ValueError('model directory must not be a symlink')
    root = args.models.resolve(strict=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), PublicRedirect())
    with args.output.open('x') as log:
        for role, fact, url in inventory:
            directory = root / role
            directory.mkdir(mode=0o700, exist_ok=True)
            if directory.is_symlink():
                raise ValueError('role directory must not be a symlink')
            started = time.time()
            try:
                record = fetch(directory / fact['path'], fact, url, args.deadline_unix, opener)
            except BaseException as exc:
                log.write(json.dumps({'role': role, 'path': fact['path'], 'status': 'failed',
                                     'exception_type': type(exc).__name__, 'started_unix': started,
                                     'finished_unix': time.time()}) + '\n')
                log.flush()
                raise
            log.write(json.dumps({'role': role, **record, 'started_unix': started,
                                  'finished_unix': time.time()}) + '\n')
            log.flush()
    signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
