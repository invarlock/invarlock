# InvarLock captured comparison

**Recorded policy result: Policy not met**

The observed NLL ratio was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits. Across 8 usable pairs, the subject's Reference NLL was 0.1287 nats / byte, compared with 0.1964 nats / byte for the baseline, giving a subject-to-baseline ratio of 0.6549. The 95% interval for the ratio runs from 0.3071 to 1.115. The policy requires the interval to stay at or below 1.05.

## What was compared


### Recorded run: Differs

- **Baseline:** live-hugging-face-evaluate-baseline
- **Subject:** live-hugging-face-evaluate-subject

### Matching displayed fields

Matching previews do not establish equality of the complete retained fields.

- **Evaluator:** hugging-face-evaluate 0.4.6
- **Model revision:** Unavailable in recorded context
- **Capture role:** Unavailable in recorded context
- **Workflow:** Unavailable in recorded context
- **Dataset:** Mixed or incomplete across records
- **Records:** 8
- **Effective message roles:** Unavailable in recorded context

### Additional fields

- **Evaluation mode:** Captured evaluator outputs

### Recorded changes

- Model-key comparison is unavailable because recorded values are missing or mixed.
- Prompt comparison unavailable in this report projection: no complete, uniquely paired supported message view is available.

## What was checked

- **Pack format:** invarlock/evidence-pack-v2
- **Input checks:** Evidence structure and comparison bindings checked.
- **Signing:** Signed manifest verified. This rendering has not authenticated it against a recipient-owned key.
- **Replay and scoring:** Scoring and replay were not performed by report.
- **Independent recipient verification:** Not performed by report. Use invarlock verify with independently supplied inputs.

## Reference NLL: overall

**Policy not met**. The observed NLL ratio was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits.

| Baseline | Subject | Change | Usable pairs |
| --- | --- | --- | --- |
| 0.1964 nats / byte | 0.1287 nats / byte | 0.6549 ratio | 8 |

Usable pairs: 0 missing · 8 included · ≥ 8 required.

95% paired-schedule ratio resampling interval &#40;Paired percentile resampling&#41;: [0.3071, 1.115] ratio.

### How to read this comparison

**Change:** The marker shows the observed change between subject and baseline. A ratio divides the subject value by the baseline value; 1 means no change.

**Interval:** The bar shows uncertainty around that change. Its left endpoint is the lower bound; its right endpoint is the upper bound. The interval level does not tell you how often model runs would pass or fail the policy.

**Policy rule:** The upper bound &#40;right endpoint&#41; must be at most the policy maximum. The whole interval must lie on the allowed side of the threshold for this bound check to pass.

**No change:** The dashed line marks no change. An interval crossing it includes changes in either direction. A worse observed score describes this run; policy rejection alone does not prove worse performance beyond these cases.

### How this interval was calculated

The declared percentile method resamples the same 8 paired records in this scope with replacement, keeping each baseline and subject result together. Its retained resampling count is 2,048.

The central 95% of that distribution describes the subject-to-baseline mean NLL ratio. Each side's NLL uses nats per expected UTF-8 byte.

This is a fixed-schedule resampling interval, not a population confidence interval. Separate metric and scope intervals do not give a simultaneous confidence guarantee or establish a representative production sample.

### Decision checks

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| Complete paired results | 8 of 8 | All included pairs | Passed |
| Included pair count | 8 | &gt;= 8 | Passed |
| Maximum NLL ratio | 1.115 ratio | &lt;= 1.05 ratio | Not met |
| Interval width | 0.8083 ratio | &lt;= 0.1 ratio | Not met |

- Lower values are better.
- Recorded scoring basis: captured reference-continuation likelihood facts; NLL means, ratio and interval were recomputed when the comparison was created. Model execution and the supplied likelihood facts are not independently established.
- 8 usable pairs; 0 missing results; 8 included pairs. Counts in overlapping slices must not be added together.

## Next steps

1. Review the recorded checks against the approved requirements.
2. For a signed handoff, run invarlock verify with independent signer, policy, request and complete-run anchors and an external signed receipt.
3. Use the comparison JSON and JUnit outputs in CI; preserve missing results and the original policy.

## Scope and limitations

- Recorded scores retain source judgments; only their aggregation is recomputed.
- Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.
- Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.
- A policy pass does not establish truthful model execution, general quality, safety or compliance.
- Normalized NLL replays captured reference-continuation likelihood facts; their model execution, tokenizer and configuration claims are source assertions, not independently established runtime facts.
- Model and prompt context is evaluator-recorded provenance, not independent execution or model-identity attestation.

## Evidence identities

- **Manifest:** sha256:9ec0e14a20cc8c91265db041e891cdbb22ed862afb470004499c814dc1fc02bb
- **Comparison:** sha256:a38c2b0b7d9a7ddfe4a46c460749d62edba56337150f49ec907322f877d121b7
- **Evidence signer:** sha256:fcfc88a2ba1b3f1903749193bb39d65f9d7513d6c24e2725c8540aff7e153ec4
- **Baseline run:** live-hugging-face-evaluate-baseline
- **Baseline run digest:** sha256:3bf928493f8b72701942b88211b9288433270c2b20b408613f6c99709ddca9bf
- **Baseline attributed artifact:** sha256:c8e5d83cef2df1fa38f189fbbaab100571622addb05bb812fcc324cadbf099ec
- **Baseline evaluator:** hugging-face-evaluate 0.4.6
- **Subject run:** live-hugging-face-evaluate-subject
- **Subject run digest:** sha256:f3c04cbaa7d487e52ce1c596705f8f5a89beb697c0c1db12f8596c75244e9d9e
- **Subject attributed artifact:** sha256:301a07d113d1964b69f497b54a8bc32a44f3b8ce0899e03e74809fa660c04067
- **Subject evaluator:** hugging-face-evaluate 0.4.6
- **Baseline binding:** sha256:3bf928493f8b72701942b88211b9288433270c2b20b408613f6c99709ddca9bf
- **Policy binding:** sha256:5f0afa87f070744e2c7d209c19d806d161a42ff6af60235de11eaaf92f4a902d
- **Subject binding:** sha256:f3c04cbaa7d487e52ce1c596705f8f5a89beb697c0c1db12f8596c75244e9d9e

## Recorded metric and scope identifiers

```json
[
  {
    "display_metric": "Reference NLL",
    "display_scope": "overall",
    "metric": "reference_nll",
    "result": 1,
    "scope": "overall"
  }
]
```

## Bound policy &#40;configuration preview&#41;

```json
{
  "format": "invarlock/comparison-policy-v1",
  "metrics": [
    {
      "aggregation": "mean",
      "configuration": {
        "limits": {
          "depth": 6,
          "nodes": 128,
          "string_characters": 256
        },
        "note": "Display preview, not a replacement configuration. Full configuration remains in evidence under the original policy binding.",
        "preview_only": true,
        "text": "{\n  \"baseline_tokenizer_digest\": \"sha256:11539bde3507db70de31a5931152d0907f24972b41b17468b3ea0f4d9fa70299\",\n  \"configuration_digest\": \"sha256:2d75fd6e15ad9ab37c6c25aa1293a29cd6e7c31849ae3e5ecc4dcd1f49c37c17\",\n  \"subject_tokenizer_digest\": \"sha256:bef458384298d886e4e30ac9262f18d7cfc14adf71b2643a2935237b7bd3f7c1\"\n}"
      },
      "direction": "lower",
      "kind": "normalized_nll_per_utf8_byte",
      "maximum_interval_width": 0.1,
      "minimum_count": 8,
      "name": "reference_nll",
      "ratio_max": 1.05,
      "unit": "nats_per_utf8_byte"
    }
  ],
  "slices": []
}
```

## Exact comparison data

```json
{
  "bindings": {
    "baseline": "sha256:3bf928493f8b72701942b88211b9288433270c2b20b408613f6c99709ddca9bf",
    "policy": "sha256:5f0afa87f070744e2c7d209c19d806d161a42ff6af60235de11eaaf92f4a902d",
    "subject": "sha256:f3c04cbaa7d487e52ce1c596705f8f5a89beb697c0c1db12f8596c75244e9d9e"
  },
  "decision": "regression",
  "format": "invarlock/multi-metric-comparison-v1",
  "limitations": [
    "Recorded scores retain source judgments; only their aggregation is recomputed.",
    "Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.",
    "Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.",
    "A policy pass does not establish truthful model execution, general quality, safety or compliance.",
    "Normalized NLL replays captured reference-continuation likelihood facts; their model execution, tokenizer and configuration claims are source assertions, not independently established runtime facts."
  ],
  "metrics": [
    {
      "aggregation": "mean",
      "baseline_mean": 0.19643798231362017,
      "count": 8,
      "decision": "regression",
      "delta": -0.06778507092189354,
      "direction": "lower",
      "interval": {
        "lower": 0.30714215851201043,
        "mass": 0.95,
        "method": "paired_percentile_bootstrap_sha256_v1",
        "replicates": 2048,
        "upper": 1.1154059258450324
      },
      "interval_unit": "ratio",
      "kind": "normalized_nll_per_utf8_byte",
      "missing_count": 0,
      "missing_ids_preview": [],
      "missing_ids_preview_is_complete": true,
      "name": "reference_nll",
      "ratio": 0.6549288985585675,
      "reasons": [
        "upper ratio interval bound exceeds ratio_max"
      ],
      "scoring_assurance": "recomputed",
      "slice": "overall",
      "subject_mean": 0.12865291139172663,
      "unit": "nats_per_utf8_byte"
    }
  ]
}
```
