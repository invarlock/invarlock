# InvarLock captured comparison

**Recorded policy result: Policy not met**

The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits. Across 8 usable pairs, the subject's Reference accuracy was 12.5%, compared with 0% for the baseline, a change of +12.5 pp. The 95% interval for the change runs from -21.52 to 47.09 pp. The policy requires the interval to stay at or above -2 pp. No absolute minimum score is required by this policy.

## What was compared


### Recorded run: Differs

- **Baseline:** live-lm-evaluation-harness-baseline
- **Subject:** live-lm-evaluation-harness-subject

### Matching displayed fields

Matching previews do not establish equality of the complete retained fields.

- **Evaluator:** lm-evaluation-harness 0.4.12
- **Model revision:** Unavailable in recorded context
- **Capture role:** Unavailable in recorded context
- **Workflow:** Unavailable in recorded context
- **Dataset:** Mixed or incomplete across records
- **Records:** 8
- **Effective message roles:** Unavailable in recorded context

### Additional fields

- **Evaluation mode:** Captured evaluator outputs

### Recorded changes

- Model-key comparison is unavailable because recorded values are missing or mixed.
- Prompt comparison unavailable in this report projection: no complete, uniquely paired supported message view is available.

## What was checked

- **Pack format:** invarlock/evidence-pack-v2
- **Input checks:** Evidence structure and comparison bindings checked.
- **Signing:** Signed manifest verified. This rendering has not authenticated it against a recipient-owned key.
- **Replay and scoring:** Scoring and replay were not performed by report.
- **Independent recipient verification:** Not performed by report. Use invarlock verify with independently supplied inputs.

## Reference accuracy: overall

**Policy not met**. The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits.

| Baseline | Subject | Change | Usable pairs |
| --- | --- | --- | --- |
| 0% | 12.5% | +12.5 pp | 8 |

Baseline: 0 of 8 matched.

Subject: 1 of 8 matched.

Usable pairs: 0 missing · 8 included · ≥ 8 required.

Paired 95% confidence interval &#40;Newcombe hybrid score&#41;: [-21.52, 47.09] pp.

### How to read this comparison

**Change:** The marker shows the observed change between subject and baseline. A change in percentage points &#40;pp&#41; is the subject percentage minus the baseline percentage.

**Interval:** The bar shows uncertainty around that change. Its left endpoint is the lower bound; its right endpoint is the upper bound. The interval level does not tell you how often model runs would pass or fail the policy.

**Policy rule:** The paired lower bound &#40;left endpoint&#41; must be at least the policy minimum. The whole interval must lie on the allowed side of the threshold for this bound check to pass.

**No change:** The dashed line marks no change. An interval crossing it includes changes in either direction. A worse observed score describes this run; policy rejection alone does not prove worse performance beyond these cases.

### How this interval was calculated

Baseline and subject are paired on the same 8 cases in this scope. Newcombe hybrid score uses their paired match outcomes to form a nominal 95% confidence interval for the accuracy change.

Change is subject accuracy minus baseline accuracy in percentage points, not relative percent change. The confidence level describes the interval method, not the share of correct answers.

Each metric and scope has its own interval; these intervals do not provide a simultaneous confidence guarantee across all results or establish a representative production sample.

### Decision checks

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| Complete paired results | 8 of 8 | All included pairs | Passed |
| Included pair count | 8 | &gt;= 8 | Passed |
| Allowed change | -21.52 pp | &gt;= -2 pp | Not met |
| Interval width | 68.61 pp | &lt;= 10 pp | Not met |

- Higher values are better.
- Recorded scoring basis: expected and output values, scored when the comparison was created.
- 8 usable pairs; 0 missing results; 8 included pairs. Counts in overlapping slices must not be added together.
- Matches: baseline 0 of 8; subject 1 of 8.
- No absolute minimum score is required by this policy.

## Next steps

1. Review the recorded checks against the approved requirements.
2. For a signed handoff, run invarlock verify with independent signer, policy, request and complete-run anchors and an external signed receipt.
3. Use the comparison JSON and JUnit outputs in CI; preserve missing results and the original policy.

## Scope and limitations

- Recorded scores retain source judgments; only their aggregation is recomputed.
- Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.
- Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.
- A policy pass does not establish truthful model execution, general quality, safety or compliance.
- Model and prompt context is evaluator-recorded provenance, not independent execution or model-identity attestation.

## Evidence identities

- **Manifest:** sha256:87b9c7cc9c40322003cbc46cdd5d6d50b11f19589f39e39c0d8fac7bab453404
- **Comparison:** sha256:d6b16d13fc64dfaec9462c4a6a2c07ee59f77edebd1cf5a0853e9b1320497cf7
- **Evidence signer:** sha256:443a48e71c0aa1e2962dee44d289256ef9e22f2c9f41d6c6ca0c2bc7d289f1c1
- **Baseline run:** live-lm-evaluation-harness-baseline
- **Baseline run digest:** sha256:5a3b4993954ee50d02ff074a3713f6172f595b176e61b69c09c1433178432652
- **Baseline attributed artifact:** sha256:c8e5d83cef2df1fa38f189fbbaab100571622addb05bb812fcc324cadbf099ec
- **Baseline evaluator:** lm-evaluation-harness 0.4.12
- **Subject run:** live-lm-evaluation-harness-subject
- **Subject run digest:** sha256:9c5d397f3cdeaee9cbef1150bff71362b6ebf36a0ef03f007a4520bd3fe4330f
- **Subject attributed artifact:** sha256:301a07d113d1964b69f497b54a8bc32a44f3b8ce0899e03e74809fa660c04067
- **Subject evaluator:** lm-evaluation-harness 0.4.12
- **Baseline binding:** sha256:5a3b4993954ee50d02ff074a3713f6172f595b176e61b69c09c1433178432652
- **Policy binding:** sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e
- **Subject binding:** sha256:9c5d397f3cdeaee9cbef1150bff71362b6ebf36a0ef03f007a4520bd3fe4330f

## Recorded metric and scope identifiers

```json
[
  {
    "display_metric": "Reference accuracy",
    "display_scope": "overall",
    "metric": "reference_accuracy",
    "result": 1,
    "scope": "overall"
  }
]
```

## Bound policy &#40;configuration preview&#41;

```json
{
  "format": "invarlock/comparison-policy-v1",
  "metrics": [
    {
      "aggregation": "mean",
      "configuration": {
        "limits": {
          "depth": 6,
          "nodes": 128,
          "string_characters": 256
        },
        "note": "Display preview, not a replacement configuration. Full configuration remains in evidence under the original policy binding.",
        "preview_only": true,
        "text": "{}"
      },
      "direction": "higher",
      "kind": "exact_match",
      "maximum_interval_width": 0.1,
      "maximum_regression": 0.02,
      "minimum_count": 8,
      "name": "reference_accuracy",
      "unit": "score"
    }
  ],
  "slices": []
}
```

## Exact comparison data

```json
{
  "bindings": {
    "baseline": "sha256:5a3b4993954ee50d02ff074a3713f6172f595b176e61b69c09c1433178432652",
    "policy": "sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e",
    "subject": "sha256:9c5d397f3cdeaee9cbef1150bff71362b6ebf36a0ef03f007a4520bd3fe4330f"
  },
  "decision": "regression",
  "format": "invarlock/multi-metric-comparison-v1",
  "limitations": [
    "Recorded scores retain source judgments; only their aggregation is recomputed.",
    "Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.",
    "Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.",
    "A policy pass does not establish truthful model execution, general quality, safety or compliance."
  ],
  "metrics": [
    {
      "aggregation": "mean",
      "baseline_mean": 0.0,
      "count": 8,
      "decision": "regression",
      "delta": 0.125,
      "direction": "higher",
      "interval": {
        "lower": -0.2152402668913369,
        "mass": 0.95,
        "method": "newcombe_hybrid_score_paired_v2",
        "replicates": 0,
        "upper": 0.4708881822128535
      },
      "kind": "exact_match",
      "missing_count": 0,
      "missing_ids_preview": [],
      "missing_ids_preview_is_complete": true,
      "name": "reference_accuracy",
      "reasons": [
        "lower interval bound exceeds allowed regression"
      ],
      "scoring_assurance": "recomputed",
      "slice": "overall",
      "subject_mean": 0.125,
      "unit": "score"
    }
  ]
}
```
