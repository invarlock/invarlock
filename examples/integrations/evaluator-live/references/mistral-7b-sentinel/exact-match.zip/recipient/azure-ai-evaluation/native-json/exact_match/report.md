# InvarLock captured comparison

**Recorded policy result: Policy not met**

The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits. Across 8 usable pairs, the subject's Reference accuracy was 12.5%, compared with 0% for the baseline, a change of +12.5 pp. The 95% interval for the change runs from -21.52 to 47.09 pp. The policy requires the interval to stay at or above -2 pp. No absolute minimum score is required by this policy.

## What was compared


### Recorded run: Differs

- **Baseline:** live-azure-ai-evaluation-baseline
- **Subject:** live-azure-ai-evaluation-subject

### Matching displayed fields

Matching previews do not establish equality of the complete retained fields.

- **Evaluator:** azure-ai-evaluation 1.18.1
- **Model revision:** Unavailable in recorded context
- **Capture role:** Unavailable in recorded context
- **Workflow:** Unavailable in recorded context
- **Dataset:** Mixed or incomplete across records
- **Records:** 8
- **Effective message roles:** Unavailable in recorded context

### Additional fields

- **Evaluation mode:** Captured evaluator outputs

### Recorded changes

- Model-key comparison is unavailable because recorded values are missing or mixed.
- Prompt comparison unavailable in this report projection: no complete, uniquely paired supported message view is available.

## What was checked

- **Pack format:** invarlock/evidence-pack-v2
- **Input checks:** Evidence structure and comparison bindings checked.
- **Signing:** Signed manifest verified. This rendering has not authenticated it against a recipient-owned key.
- **Replay and scoring:** Scoring and replay were not performed by report.
- **Independent recipient verification:** Not performed by report. Use invarlock verify with independently supplied inputs.

## Reference accuracy: overall

**Policy not met**. The observed change was within the policy limit, but its uncertainty interval extended beyond it. The uncertainty interval is wider than the policy permits.

| Baseline | Subject | Change | Usable pairs |
| --- | --- | --- | --- |
| 0% | 12.5% | +12.5 pp | 8 |

Baseline: 0 of 8 matched.

Subject: 1 of 8 matched.

Usable pairs: 0 missing · 8 included · ≥ 8 required.

Paired 95% confidence interval &#40;Newcombe hybrid score&#41;: [-21.52, 47.09] pp.

### How to read this comparison

**Change:** The marker shows the observed change between subject and baseline. A change in percentage points &#40;pp&#41; is the subject percentage minus the baseline percentage.

**Interval:** The bar shows uncertainty around that change. Its left endpoint is the lower bound; its right endpoint is the upper bound. The interval level does not tell you how often model runs would pass or fail the policy.

**Policy rule:** The paired lower bound &#40;left endpoint&#41; must be at least the policy minimum. The whole interval must lie on the allowed side of the threshold for this bound check to pass.

**No change:** The dashed line marks no change. An interval crossing it includes changes in either direction. A worse observed score describes this run; policy rejection alone does not prove worse performance beyond these cases.

### How this interval was calculated

Baseline and subject are paired on the same 8 cases in this scope. Newcombe hybrid score uses their paired match outcomes to form a nominal 95% confidence interval for the accuracy change.

Change is subject accuracy minus baseline accuracy in percentage points, not relative percent change. The confidence level describes the interval method, not the share of correct answers.

Each metric and scope has its own interval; these intervals do not provide a simultaneous confidence guarantee across all results or establish a representative production sample.

### Decision checks

| Check | Observed | Required | Result |
| --- | --- | --- | --- |
| Complete paired results | 8 of 8 | All included pairs | Passed |
| Included pair count | 8 | &gt;= 8 | Passed |
| Allowed change | -21.52 pp | &gt;= -2 pp | Not met |
| Interval width | 68.61 pp | &lt;= 10 pp | Not met |

- Higher values are better.
- Recorded scoring basis: expected and output values, scored when the comparison was created.
- 8 usable pairs; 0 missing results; 8 included pairs. Counts in overlapping slices must not be added together.
- Matches: baseline 0 of 8; subject 1 of 8.
- No absolute minimum score is required by this policy.

## Next steps

1. Review the recorded checks against the approved requirements.
2. For a signed handoff, run invarlock verify with independent signer, policy, request and complete-run anchors and an external signed receipt.
3. Use the comparison JSON and JUnit outputs in CI; preserve missing results and the original policy.

## Scope and limitations

- Recorded scores retain source judgments; only their aggregation is recomputed.
- Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.
- Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.
- A policy pass does not establish truthful model execution, general quality, safety or compliance.
- Model and prompt context is evaluator-recorded provenance, not independent execution or model-identity attestation.

## Evidence identities

- **Manifest:** sha256:1d49c72ba2a2ea76751fdf9f617c27cedf1dbe1eb56ef36fdedd7f2d1989662c
- **Comparison:** sha256:a746aec967041a59f161bbcea771a0686036885fe507bddec2e47483bacbaf51
- **Evidence signer:** sha256:b1d0d9cb440795c4a53d3ac7566f422776fd08d792f879549e9134e12afd648f
- **Baseline run:** live-azure-ai-evaluation-baseline
- **Baseline run digest:** sha256:0f919488500d49d01fd8083d162721fa7723b272cbaaecee374a95a3751359a3
- **Baseline attributed artifact:** sha256:c8e5d83cef2df1fa38f189fbbaab100571622addb05bb812fcc324cadbf099ec
- **Baseline evaluator:** azure-ai-evaluation 1.18.1
- **Subject run:** live-azure-ai-evaluation-subject
- **Subject run digest:** sha256:359ac7b3e4d57dfd0c105af4d47268361a6460feecd584c3ed3c9d928e2d704a
- **Subject attributed artifact:** sha256:301a07d113d1964b69f497b54a8bc32a44f3b8ce0899e03e74809fa660c04067
- **Subject evaluator:** azure-ai-evaluation 1.18.1
- **Baseline binding:** sha256:0f919488500d49d01fd8083d162721fa7723b272cbaaecee374a95a3751359a3
- **Policy binding:** sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e
- **Subject binding:** sha256:359ac7b3e4d57dfd0c105af4d47268361a6460feecd584c3ed3c9d928e2d704a

## Recorded metric and scope identifiers

```json
[
  {
    "display_metric": "Reference accuracy",
    "display_scope": "overall",
    "metric": "reference_accuracy",
    "result": 1,
    "scope": "overall"
  }
]
```

## Bound policy &#40;configuration preview&#41;

```json
{
  "format": "invarlock/comparison-policy-v1",
  "metrics": [
    {
      "aggregation": "mean",
      "configuration": {
        "limits": {
          "depth": 6,
          "nodes": 128,
          "string_characters": 256
        },
        "note": "Display preview, not a replacement configuration. Full configuration remains in evidence under the original policy binding.",
        "preview_only": true,
        "text": "{}"
      },
      "direction": "higher",
      "kind": "exact_match",
      "maximum_interval_width": 0.1,
      "maximum_regression": 0.02,
      "minimum_count": 8,
      "name": "reference_accuracy",
      "unit": "score"
    }
  ],
  "slices": []
}
```

## Exact comparison data

```json
{
  "bindings": {
    "baseline": "sha256:0f919488500d49d01fd8083d162721fa7723b272cbaaecee374a95a3751359a3",
    "policy": "sha256:25e58b917b2a28d2ffa2412fbcd0a4d7cafaeab5686f5a9a8c3e8460412f796e",
    "subject": "sha256:359ac7b3e4d57dfd0c105af4d47268361a6460feecd584c3ed3c9d928e2d704a"
  },
  "decision": "regression",
  "format": "invarlock/multi-metric-comparison-v1",
  "limitations": [
    "Recorded scores retain source judgments; only their aggregation is recomputed.",
    "Intervals describe the paired schedule under the stated method; representativeness requires an external sampling design.",
    "Metric and slice intervals are marginal, not a simultaneous family-wide confidence guarantee.",
    "A policy pass does not establish truthful model execution, general quality, safety or compliance."
  ],
  "metrics": [
    {
      "aggregation": "mean",
      "baseline_mean": 0.0,
      "count": 8,
      "decision": "regression",
      "delta": 0.125,
      "direction": "higher",
      "interval": {
        "lower": -0.2152402668913369,
        "mass": 0.95,
        "method": "newcombe_hybrid_score_paired_v2",
        "replicates": 0,
        "upper": 0.4708881822128535
      },
      "kind": "exact_match",
      "missing_count": 0,
      "missing_ids_preview": [],
      "missing_ids_preview_is_complete": true,
      "name": "reference_accuracy",
      "reasons": [
        "lower interval bound exceeds allowed regression"
      ],
      "scoring_assurance": "recomputed",
      "slice": "overall",
      "subject_mean": 0.125,
      "unit": "score"
    }
  ]
}
```
