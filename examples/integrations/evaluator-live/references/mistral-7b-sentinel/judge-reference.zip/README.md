Retained live judge reference

Historical eight-case SDK integration sentinel. The archive preserves 32 original blocked/ambiguous attempts separately from 992 completed Luna ratings, including 32 later correction ratings. All 52 original policy decisions are insufficient_evidence; this is not a powered model-quality claim.

Original signed bytes remain unchanged. Sources retain normalized Inspect model-event bytes exactly as embedded in measurements. The separate companion EM/NLL archive is required to inspect original native SDK/model capture artifacts and recovery histories. Public signer/verifier keys remain embedded in signatures. All private PEM keys and execution authorization documents are excluded. The correction entries are separate and do not replace either original failed Inspect entry.
