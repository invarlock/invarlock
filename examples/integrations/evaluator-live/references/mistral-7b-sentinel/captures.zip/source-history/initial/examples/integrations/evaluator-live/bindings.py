"""Explicit capture bindings around unchanged local runtime observations.

The SDK records measurements made by the separate model worker. Its source and
input wrapper identify the capture, not the implementation that computed logits.
The original response remains in the transport ledger and in record metadata.
"""

from __future__ import annotations

from copy import deepcopy

import common


def native_input(evaluator, case):
    if evaluator == "lm-evaluation-harness":
        return deepcopy(case)
    if evaluator == "promptfoo":
        return {"prompt": case["input"], "case_id": case["id"]}
    return case["input"]


def projection(evaluator):
    pointer = {
        "lm-evaluation-harness": "/input/input",
        "promptfoo": "/input/prompt",
    }.get(evaluator)
    return {"kind": "json-pointer", "pointer": pointer} if pointer else None


def bind_result(result, case, evaluator, version):
    """Add a declared capture binding without modifying the worker response."""
    value = deepcopy(result)
    metadata = value["metadata"]
    if {"invarlock_capture_binding", "invarlock_task_outcome"} & metadata.keys():
        raise ValueError("runtime response cannot supply a capture binding")
    metadata["invarlock_task_outcome"] = {
        "output": result["output"],
        "error": result.get("error"),
    }
    original = metadata.get("invarlock_likelihood")
    if original is None:
        return value
    execution = metadata.get("invarlock_model_execution", {})
    if (
        original["input_digest"] != common.digest(case["input"])
        or original["reference_digest"] != common.digest(case["expected"])
        or original["utf8_byte_count"] != len(case["expected"].encode("utf-8"))
        or original["source"] != execution.get("source")
        or original["artifact_digest"]
        != execution.get("model", {}).get("artifact_digest")
        or original["configuration_digest"]
        != common.digest(execution.get("configuration"))
        or original["tokenizer_digest"]
        != execution.get("model", {}).get("tokenizer_digest")
    ):
        raise ValueError("runtime likelihood differs from its task or execution")
    captured_input = native_input(evaluator, case)
    facts = {
        **original,
        "input_digest": common.digest(captured_input),
        "source": {"name": evaluator, "version": version},
    }
    metadata["invarlock_capture_binding"] = {
        "format": "invarlock/live-likelihood-capture-v1",
        "original_likelihood": deepcopy(original),
        "native_input": captured_input,
        "input_projection": projection(evaluator),
        "role": "SDK capture of independently retained model-worker measurements",
    }
    metadata["invarlock_likelihood"] = facts
    return value


def check_record(record, result, case, evaluator, version):
    """Recipient-side check of normalized facts against the raw task ledger."""
    bound = bind_result(result, case, evaluator, version)
    if (
        record["id"] != case["id"]
        or record["input"] != case["input"]
        or record["expected"] != case["expected"]
        or record["output"] != result["output"]
        or common.encoded(record["metadata"])
        != common.encoded(
            {
                key: value
                for key, value in case["metadata"].items()
                if isinstance(value, str)
            }
        )
        or bool(record.get("error")) != bool(result.get("error"))
        or record.get("likelihood") != bound["metadata"].get("invarlock_likelihood")
    ):
        raise ValueError("normalized record differs from the original model task")
    retained = record["context"].get("input_projection")
    if projection(evaluator):
        if not retained or retained["source"]["input"] != native_input(evaluator, case):
            raise ValueError(
                "native input wrapper differs from the declared projection"
            )
    elif retained:
        raise ValueError("unexpected task input transformation")
