
import net from 'node:net';
import http from 'node:http';
import https from 'node:https';
import tls from 'node:tls';
import dns from 'node:dns';
import dgram from 'node:dgram';
import http2 from 'node:http2';
import {syncBuiltinESMExports} from 'node:module';
const endpoint = new URL(process.env.LIVE_TASK_URL);
if(endpoint.protocol!=='http:' || endpoint.hostname!=='127.0.0.1' || endpoint.pathname!=='/task')
  throw Error('invalid local callback endpoint');
const blocked=()=>{throw Error('live Promptfoo capture forbids external networking');};
const socketConnect=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){
  let options=args[0];
  if(Array.isArray(options)) options=options[0];
  if(typeof options!=='object') options={port:args[0],host:typeof args[1]==='string'?args[1]:'localhost'};
  if(!options || options.path || (options.host??options.hostname)!==endpoint.hostname ||
     Number(options.port)!==Number(endpoint.port)) blocked();
  return socketConnect.apply(this,args);
};
const request=http.request;
function localRequest(...args){
  const first=args[0];
  if(args[1] && typeof args[1]==='object' &&
     ['host','hostname','port','path','protocol','createConnection','socketPath','agent'].some(k=>k in args[1])) blocked();
  const options=typeof first==='string'||first instanceof URL ? new URL(first) : first;
  if(!options || (options.hostname??options.host)!==endpoint.hostname ||
     Number(options.port)!==Number(endpoint.port) ||
     (options.pathname??options.path??'/')!==endpoint.pathname ||
     (options.protocol??'http:')!=='http:') blocked();
  return request.apply(this,args);
}
http.request=localRequest;
http.get=function(...args){const request=localRequest(...args);request.end();return request;};
https.request=https.get=tls.connect=http2.connect=blocked;
dgram.Socket.prototype.send=dgram.Socket.prototype.connect=blocked;
for(const name of Object.keys(dns))
  if(name.startsWith('resolve')||name==='lookup'||name==='lookupService'||name==='reverse') dns[name]=blocked;
for(const name of Object.keys(dns.promises))
  if(name.startsWith('resolve')||name==='lookup'||name==='lookupService'||name==='reverse') dns.promises[name]=blocked;
const originalFetch=globalThis.fetch;
globalThis.fetch=(input,options={})=>{
  const url=new URL(typeof input==='string'||input instanceof URL?input:input.url);
  if(url.href!==endpoint.href) blocked();
  return originalFetch(input,{...options,redirect:'error'});
};
syncBuiltinESMExports();

import fs from 'node:fs';
const api = await import(process.env.LIVE_PROMPTFOO_ENTRY);
const evaluate = api.evaluate ?? api.default?.evaluate;
if (!evaluate) throw Error('Promptfoo evaluate API unavailable');
const cases = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const provider = {id:()=> 'local-live-callback', callApi:async (prompt, context)=> {
  const response = await fetch(process.env.LIVE_TASK_URL, {method:'POST',
    headers:{'Authorization':process.env.LIVE_TASK_TOKEN,'Content-Type':'application/json'},
    body:JSON.stringify({id:context.vars.case_id,prompt})});
  if(!response.ok) throw Error(`local task bridge returned ${response.status}`);
  return await response.json();
}};
const result = await evaluate({prompts:['{{prompt}}'],providers:[provider],tests:cases.map(c=>({
  vars:{prompt:c.input,case_id:c.id},metadata:{...c.metadata,invarlock_id:c.id,invarlock_expected:c.expected},
  assert:[{type:'equals',value:c.expected}]
}))}, {maxConcurrency:1,cache:false,writeLatestResults:false});
const rows=(await result.toEvaluateSummary()).results;
fs.writeFileSync(process.argv[3], JSON.stringify(rows));
